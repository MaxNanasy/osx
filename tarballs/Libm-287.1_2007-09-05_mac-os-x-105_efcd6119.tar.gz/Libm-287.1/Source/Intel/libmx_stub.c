/*
 *  libmx_stub.c
 *  LibmV5
 *
 *  Created by iano on 9/16/05.
 *  Copyright 2005 __MyCompanyName__. All rights reserved.
 *
 */

double __libmx_must_die_the_horible_death_it_deserves( double );
