ShrinkAllNotification = "ShrinkAllNotification"
