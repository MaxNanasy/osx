require File.join(File.dirname(__FILE__), 'make_fasta_output')
prepare_fasta_output(100_000)
