# frozen_string_literal: false
create_makefile("-test-/gvl/call_without_gvl")
