# frozen_string_literal: false
create_makefile("-test-/bug-3571/bug")
