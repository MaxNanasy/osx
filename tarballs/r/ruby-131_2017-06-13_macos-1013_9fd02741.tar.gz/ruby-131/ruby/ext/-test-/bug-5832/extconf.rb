# frozen_string_literal: false
create_makefile("-test-/bug-5832/bug")
