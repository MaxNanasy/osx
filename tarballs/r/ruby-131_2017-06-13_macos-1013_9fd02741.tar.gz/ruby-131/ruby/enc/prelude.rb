begin
  require 'unicode_normalize'
rescue LoadError
end
