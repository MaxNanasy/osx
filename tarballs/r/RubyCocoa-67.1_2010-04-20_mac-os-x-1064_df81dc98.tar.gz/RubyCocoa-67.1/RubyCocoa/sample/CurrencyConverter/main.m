// $Id: main.m 792 2005-04-30 15:45:42Z kimuraw $
#import <RubyCocoa/RBRuntime.h>

int main(int argc, const char *argv[])
{
    return RBApplicationMain("rb_main.rb", argc, argv);
}
