#
#  TclX support
#                               by Hidetoshi NAGAI (nagai@ai.kyutech.ac.jp)
#

# call setup script for general 'tkextlib' libraries
require 'tkextlib/setup.rb'

# call setup script
require 'tkextlib/tclx/setup.rb'

# load library
require 'tkextlib/tclx/tclx'
