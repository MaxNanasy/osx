#include "AudioHardwareObjectInterface.h"

OSDefineMetaClassAndAbstractStructors(AudioHardwareObjectInterface, IOService);

