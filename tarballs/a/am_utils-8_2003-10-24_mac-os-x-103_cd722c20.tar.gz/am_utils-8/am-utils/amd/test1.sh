#!/bin/sh
./amd -v 2> /dev/null
