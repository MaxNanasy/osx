/* $srcdir/conf/fh_dref/fh_dref_nextstep.h */
#define	NFS_FH_DREF(dst, src) (dst) = (caddr_t) (src)
