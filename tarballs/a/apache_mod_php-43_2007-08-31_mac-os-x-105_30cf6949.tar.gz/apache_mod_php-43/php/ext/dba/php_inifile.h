#ifndef PHP_INIFILE_H
#define PHP_INIFILE_H

#if DBA_INIFILE

#include "php_dba.h"

DBA_FUNCS(inifile);

#endif

#endif
