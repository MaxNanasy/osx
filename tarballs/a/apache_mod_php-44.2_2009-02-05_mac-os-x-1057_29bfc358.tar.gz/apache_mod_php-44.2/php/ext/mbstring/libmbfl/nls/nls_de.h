#ifndef MBFL_NLS_DE_H
#define MBFL_NLS_DE_H

#include "mbfilter.h"

extern const mbfl_language mbfl_language_german;

#endif /* MBFL_NLS_DE_H */
