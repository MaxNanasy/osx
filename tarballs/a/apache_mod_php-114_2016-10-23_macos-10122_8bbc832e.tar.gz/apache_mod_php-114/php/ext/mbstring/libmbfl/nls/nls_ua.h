#ifndef MBFL_NLS_UA_H
#define MBFL_NLS_UA_H

#include "mbfilter.h"
#include "nls_ua.h"

extern const mbfl_language mbfl_language_ukrainian;

#endif /* MBFL_NLS_UA_H */
