/*
 *  AppleOnyxAudio.cpp
 *  AppleOnboardAudio
 *
 *  Created by AudioSW Team on Mon Jun 16 2003.
 *  Copyright (c) 2003 Apple. All rights reserved.
 *
 */

#include "AppleOnyxAudio.h"
#include "PlatformInterface.h"
#include "AudioHardwareUtilities.h"



