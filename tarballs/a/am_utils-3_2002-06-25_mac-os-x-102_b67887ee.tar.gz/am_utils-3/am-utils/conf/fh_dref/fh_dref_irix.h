/* $srcdir/conf/fh_dref/fh_dref_irix.h */
#define	NFS_FH_DREF(dst, src) (dst) = (fhandle_t *) (src)
