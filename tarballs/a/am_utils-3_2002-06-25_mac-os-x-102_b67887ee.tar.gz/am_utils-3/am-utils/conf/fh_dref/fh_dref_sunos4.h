/* $srcdir/conf/fh_dref/fh_dref_sunos4.h */
#define	NFS_FH_DREF(dst, src) (dst) = (caddr_t) (src)
