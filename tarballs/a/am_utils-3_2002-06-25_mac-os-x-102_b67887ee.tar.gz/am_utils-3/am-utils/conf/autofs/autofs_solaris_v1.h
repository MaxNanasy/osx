#ifdef HAVE_FS_AUTOFS
typedef struct autofs_args autofs_fh_t;
#endif /* HAVE_FS_AUTOFS */
