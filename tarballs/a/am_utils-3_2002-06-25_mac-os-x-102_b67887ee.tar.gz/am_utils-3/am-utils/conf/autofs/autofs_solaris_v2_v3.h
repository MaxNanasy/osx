#ifdef HAVE_FS_AUTOFS
typedef struct autofs_args autofs_fh_t;
typedef struct action_list autofs_data_t;
#endif /* HAVE_FS_AUTOFS */
