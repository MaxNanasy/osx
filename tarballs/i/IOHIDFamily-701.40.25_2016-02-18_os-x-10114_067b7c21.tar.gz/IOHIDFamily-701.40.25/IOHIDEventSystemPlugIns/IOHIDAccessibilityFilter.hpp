//
//  IOHIDAccessibilityFilter.hpp
//  IOHIDFamily
//
//  Created by Gopu Bhaskar on 3/10/15.
//
//

#ifndef _IOHIDFamily_IOHIDAccessibilityFilter_
#define _IOHIDFamily_IOHIDAccessibilityFilter_

#include <stdio.h>

#endif /* defined(_IOHIDFamily_IOHIDAccessibilityFilter_) */
