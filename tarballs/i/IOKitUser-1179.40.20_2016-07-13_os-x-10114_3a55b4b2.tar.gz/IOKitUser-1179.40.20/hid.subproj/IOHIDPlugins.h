//
//  IOHIDFilterPlugins.h
//  IOKitUser
//
//  Created by Cliff Russell on 3/8/11.
//  Copyright 2011 Apple Inc. All rights reserved.
//

CF_EXPORT
const CFArrayCallBacks kIOHIDFilterPluginArrayCallBacks;

CF_EXPORT
void _IOHIDLoadBundles();