
#ifndef __IOFWDVComponents__
#define __IOFWDVComponents__

#define	kIsocCodecBaseID	-5736

// 'thng'
#define	kIsocCodecThing		kIsocCodecBaseID
// 'STR '
#define	kIsocCodecNameID	kIsocCodecBaseID

#define	kControlCodecBaseID	-5735

// 'thng'
#define	kControlCodecThing	kControlCodecBaseID
// 'STR '
#define	kControlCodecNameID	kControlCodecBaseID

#endif /* __IOFWDVComponents__ */

