//  VerticallyCenteredTextFieldCell.h

//  Created by Mike Morton on Mon May 27 2002.
//  Copyright (c) 2002 Apple Computer, Inc. All rights reserved.

#import <Cocoa/Cocoa.h>

@interface VerticallyCenteredTextFieldCell : NSTextFieldCell
{

}


@end