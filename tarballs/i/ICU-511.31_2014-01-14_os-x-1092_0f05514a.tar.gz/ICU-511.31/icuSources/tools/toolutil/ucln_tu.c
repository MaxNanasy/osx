/********************************************************************
 * COPYRIGHT:
 * Copyright (c) 2007-2010, International Business Machines Corporation and
 * others. All Rights Reserved.
 ********************************************************************/


/**  Auto-client **/
#define UCLN_TYPE UCLN_TOOLUTIL
#include "ucln_imp.h"

int dummyFunction(void);
int dummyFunction(void)
{
  /* this is here to prevent the compiler from complaining about an empty file */
  return 0;
}
