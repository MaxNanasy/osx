#ifndef __DVCOMPONENTGLUE__
#define __DVCOMPONENTGLUE__

#ifndef __QUICKTIME__
#include <QuickTime/QuickTime.h>
#endif

#ifndef __CORESERVICES__
#include <CoreServices/CoreServices.h>
#endif


#ifndef __ISOCHRONOUSDATAHANDLER__
#include <DVComponentGlue/IsochronousDataHandler.h>
#endif

#ifndef __DEVICECONTROL__
#include <DVComponentGlue/DeviceControl.h>
#endif


#endif /* __DVCOMPONENTGLUE__ */

