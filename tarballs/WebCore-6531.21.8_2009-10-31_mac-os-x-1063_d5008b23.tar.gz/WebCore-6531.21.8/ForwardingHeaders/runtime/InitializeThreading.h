#ifndef WebCore_FWD_InitializeThreadingn_h
#define WebCore_FWD_InitializeThreading_h
#include <JavaScriptCore/InitializeThreading.h>
#endif
