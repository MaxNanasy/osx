#ifndef WebCore_FWD_StringPrototype_h
#define WebCore_FWD_StringPrototype_h
#include <JavaScriptCore/StringPrototype.h>
#endif
