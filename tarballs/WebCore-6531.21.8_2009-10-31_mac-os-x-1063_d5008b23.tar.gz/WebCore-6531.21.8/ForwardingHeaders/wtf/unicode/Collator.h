#ifndef WebCore_FWD_Collator_h
#define WebCore_FWD_Collator_h
#include <JavaScriptCore/Collator.h>
#endif
