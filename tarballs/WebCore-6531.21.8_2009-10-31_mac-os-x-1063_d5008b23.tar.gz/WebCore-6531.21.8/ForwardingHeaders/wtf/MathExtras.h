#ifndef WebCore_FWD_MathExtras_h
#define WebCore_FWD_MathExtras_h
#include <JavaScriptCore/MathExtras.h>
#endif
