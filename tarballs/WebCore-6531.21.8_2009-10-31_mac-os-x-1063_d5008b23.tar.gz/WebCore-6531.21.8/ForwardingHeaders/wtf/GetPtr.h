#ifndef WebCore_FWD_GetPtr_h
#define WebCore_FWD_GetPtr_h
#include <JavaScriptCore/GetPtr.h>
#endif
