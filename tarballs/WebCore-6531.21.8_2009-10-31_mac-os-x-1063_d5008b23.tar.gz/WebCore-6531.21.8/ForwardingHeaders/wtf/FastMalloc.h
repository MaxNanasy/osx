#ifndef WebCore_FWD_FastMalloc_h
#define WebCore_FWD_FastMalloc_h
#include <JavaScriptCore/FastMalloc.h>
#endif
