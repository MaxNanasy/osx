#ifndef WebCore_FWD_StdLibExtras_h
#define WebCore_FWD_StdLibExtras_h
#include <JavaScriptCore/StdLibExtras.h>
#endif
