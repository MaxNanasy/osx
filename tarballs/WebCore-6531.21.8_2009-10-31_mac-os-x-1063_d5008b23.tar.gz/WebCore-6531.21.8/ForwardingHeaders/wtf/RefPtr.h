#ifndef WebCore_FWD_RefPtr_h
#define WebCore_FWD_RefPtr_h
#include <JavaScriptCore/RefPtr.h>
#endif
