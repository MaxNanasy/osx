#ifndef WebCore_FWD_Threading_h
#define WebCore_FWD_Threading_h
#include <JavaScriptCore/Threading.h>
#endif
