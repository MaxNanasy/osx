#ifndef WebCore_FWD_HashSet_h
#define WebCore_FWD_HashSet_h
#include <JavaScriptCore/HashSet.h>
#endif
