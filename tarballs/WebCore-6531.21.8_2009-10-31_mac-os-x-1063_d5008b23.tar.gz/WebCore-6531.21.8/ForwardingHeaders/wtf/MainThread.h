#ifndef WebCore_FWD_MainThread_h
#define WebCore_FWD_MainThread_h
#include <JavaScriptCore/MainThread.h>
#endif
