#define NO_DLN_LOAD 1
#include "dln.c"
