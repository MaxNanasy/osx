class KerberosFrameworkInitializer {
    public:
        KerberosFrameworkInitializer ();
        virtual ~KerberosFrameworkInitializer ();
};