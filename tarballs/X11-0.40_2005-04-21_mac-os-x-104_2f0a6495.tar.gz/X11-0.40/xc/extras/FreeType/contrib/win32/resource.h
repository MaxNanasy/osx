//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by testw32.rc
//
#define IDD_TESTW32_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDC_FONT_NAME                   1000
#define IDC_BITMAP                      1001
#define IDC_LIST_BOX                    1002
#define IDC_SELECT_ACTION               1003
#define IDC_ACTION                      1004
#define IDC_TEST_PROGRAM                1005
#define IDC_OPTIONS                     1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
