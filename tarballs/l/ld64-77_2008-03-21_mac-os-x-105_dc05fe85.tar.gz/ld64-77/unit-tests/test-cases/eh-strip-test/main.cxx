#include <vector>
int main()
{
	std::vector<int> stuff;
	return 0;
}
