int foo = 2;
int other = 3;
