extern int foo ();

int bar (void)
{
  return foo();
}
