#include <Foundation/Foundation.h>

@interface Bar : NSObject {
	int f;
}
- (void) doit;
@end

@implementation Bar
- (void) doit { }
@end

