#include "b10.h"
extern void foo(void);

struct my_struct my_hooks = {
  foo
};

