int foo3()
{
	return 21;
}

