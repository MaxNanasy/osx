#include <Foundation/Foundation.h>

@interface Bar : NSObject

-(void) blah;

@end

@implementation Bar

-(void) blah {}

@end