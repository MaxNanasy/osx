
int baz (void)
{
  return 1;
}
