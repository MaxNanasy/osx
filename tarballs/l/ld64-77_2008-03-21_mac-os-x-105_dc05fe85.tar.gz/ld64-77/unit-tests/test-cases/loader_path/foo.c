
extern int bar();

int foo()
{
	return bar();
}
