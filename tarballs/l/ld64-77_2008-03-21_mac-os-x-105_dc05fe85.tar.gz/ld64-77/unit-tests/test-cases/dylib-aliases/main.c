extern void foo();
extern void bar();

int main() {
   foo();
   bar();
   return 0;
}
