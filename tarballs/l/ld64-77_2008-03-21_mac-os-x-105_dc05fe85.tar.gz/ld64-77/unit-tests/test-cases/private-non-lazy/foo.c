

extern int foo;

int getfoo() { return foo; }


