#include <stdio.h>

extern void foo();
extern void bar();

int main()
{
	foo();
	return 0;
}
