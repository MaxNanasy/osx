#ifndef __PMAP_WAKEUP_H__
#define __PMAP_WAKEUP_H__

int pmap_wakeup(void);

#endif
