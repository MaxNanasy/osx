//
// SuperBlob - a typed bag of Blobs
//
#include "superblob.h"
#include <cstdarg>

namespace Security {


}	// Security
