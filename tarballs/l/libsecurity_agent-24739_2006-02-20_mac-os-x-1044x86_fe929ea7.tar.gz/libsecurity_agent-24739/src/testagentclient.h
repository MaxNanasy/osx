/*
 *  testagentclient.h
 *  SecurityAgent
 *
 *  Created by Conrad Sauerwald on Thu Oct 10 2002.
 *  Copyright (c) 2002 __MyCompanyName__. All rights reserved.
 *
 */


