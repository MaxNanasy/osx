Xcode project files for LLVM, for Xcode 2.1
