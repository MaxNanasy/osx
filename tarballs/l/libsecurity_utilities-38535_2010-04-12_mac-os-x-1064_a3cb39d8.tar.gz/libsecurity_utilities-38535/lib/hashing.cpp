//
// Fast hasing support
//
#include "hashing.h"


namespace Security {


}	// Security
