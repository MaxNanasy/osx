ReadMe.txt


This directory contains a program to test C's floating-point classification
macros:

	fpclassify, isnormal, isfinite, isinf, isnan, and signbit.

This program is preliminary and should be developed further.


CVS information:  $Revision: 1.1 $, $Date: 2005/04/22 23:09:41 $.
