ReadMe.txt


This directory contains documentation about Libm for the people who work on it.


CVS information:  $Revision: 1.1 $, $Date: 2005/11/01 00:11:25 $.


Contents:

	LibmxNotes.doc.

		Microsoft Word document prepared while dealing with thorny libmx
		link issues.

	SupportMatrix.html.

		Chart of support for combinations of target and SDK versions that
		arose while dealig with libmx link issues.
