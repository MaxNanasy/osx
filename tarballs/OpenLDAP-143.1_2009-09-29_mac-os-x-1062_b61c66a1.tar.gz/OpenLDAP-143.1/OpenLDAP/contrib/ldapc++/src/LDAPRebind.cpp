// $OpenLDAP: pkg/ldap/contrib/ldapc++/src/LDAPRebind.cpp,v 1.1.10.1 2008/04/14 23:09:26 quanah Exp $
/*
 * Copyright 2000, OpenLDAP Foundation, All Rights Reserved.
 * COPYING RESTRICTIONS APPLY, see COPYRIGHT file
 */

#include "LDAPRebind.h"


