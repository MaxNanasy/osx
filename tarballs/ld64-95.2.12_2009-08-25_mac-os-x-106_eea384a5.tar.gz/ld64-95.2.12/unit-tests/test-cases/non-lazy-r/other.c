int foo = 2;
int other = 3;
int tent;
