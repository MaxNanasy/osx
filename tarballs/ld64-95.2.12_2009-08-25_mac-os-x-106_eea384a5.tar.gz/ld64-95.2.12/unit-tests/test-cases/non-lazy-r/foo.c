


extern int foo;

int getfoo() { return foo; }


extern int other;

int getother() { return other; }


extern int tent;

int gettent() { return tent; }

