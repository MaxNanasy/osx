
extern int fooCount;
extern int barCount;

void foo() { fooCount++; }
void bar() { barCount++; }
int global = 4;
int googoo = 5;

