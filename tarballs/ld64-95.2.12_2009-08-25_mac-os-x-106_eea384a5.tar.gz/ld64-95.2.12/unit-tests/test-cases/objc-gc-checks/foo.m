
@interface Foo  {
	int f;
}
- (void) doit;
@end


@implementation Foo
- (void) doit {  }
@end

