


class Bar {
public:
	Bar() : a(20) {}
	~Bar() {}
private:
	int a;
};


Bar b1;
Bar b2;


