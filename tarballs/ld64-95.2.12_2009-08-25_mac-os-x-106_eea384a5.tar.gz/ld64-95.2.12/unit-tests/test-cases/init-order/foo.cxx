


class Foo {
public:
	Foo() : a(20) {}
	~Foo() {}
private:
	int a;
};


Foo f1;
Foo f2;
