#include <stdio.h>

class M {
public:
	M() : a(20) {}
	~M() {}
private:
	int a;
};


M m1;
M m2;

int main()
{
	return 0;
}
