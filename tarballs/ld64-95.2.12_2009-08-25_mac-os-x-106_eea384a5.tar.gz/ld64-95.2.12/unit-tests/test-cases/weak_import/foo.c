

#include "foo.h"

void func1() {}
void func2() {}
void func3() {}
void func4() {}


int data1 = 0;
int data2 = 0;	// weak_import initialized
int data3;
int data4;		// weak_import uninitialized
int data5 = 0;
int data6 = 0;	// weak_import 

