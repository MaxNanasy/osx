#include <stdio.h>
#include <stdlib.h>

#include "foo.h"


int main()
{
	[[Foo alloc] init];
	return 0;
}

