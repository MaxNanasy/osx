
int __attribute__((weak)) aaa()
{
	return 0;
}

int __attribute__((weak)) bbb()
{
	return 0;
}

