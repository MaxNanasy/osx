
#include <stdio.h>

#include "header.h"


void FUNC() { foo(); }

