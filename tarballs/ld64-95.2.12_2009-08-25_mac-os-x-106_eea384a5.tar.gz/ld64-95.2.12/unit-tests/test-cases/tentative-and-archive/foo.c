
extern void bar();

void foo() { bar(); }

int var = 9;
