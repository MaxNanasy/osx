

void __attribute__((weak)) foo()
{
}
