

#if AAA
	void aaa() {}
#endif

#if BBB
	void bbb() {}
#endif

#if CCC
	void ccc() {}
#endif

#if DDD
	void ddd() {}
#endif

#if EEE
	void eee() {}
#endif

#if FFFF
	void fff() {}
#endif
