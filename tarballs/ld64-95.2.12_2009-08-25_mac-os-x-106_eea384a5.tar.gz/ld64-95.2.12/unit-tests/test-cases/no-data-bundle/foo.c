#include <stdlib.h>

void foo()
{
	rand();
}