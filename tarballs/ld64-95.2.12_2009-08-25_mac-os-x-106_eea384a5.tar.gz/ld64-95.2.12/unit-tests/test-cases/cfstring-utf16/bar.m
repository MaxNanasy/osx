#include <CoreFoundation/CFString.h>


void bar()
{
	CFStringGetLength(CFSTR("über"));
}
