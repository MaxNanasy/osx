
void bar1() {}
void bar2() {}
char bar_array[3] = { 1,2,3 };

