

void func2() {}
void func4() {}


int data2 = 0;	// foo.c also has weak_import initialized
int data4;		// foo.c also has weak_import uninitialized
int data6 = 0;	// foo.c also has weak_import 

