
#include <stdio.h>


void foo(int x)
{
	printf("hello, world %d\n", x);
}

int main()
{
	foo(10);
	return 0;
}

