
int b=0;

void func() {}


