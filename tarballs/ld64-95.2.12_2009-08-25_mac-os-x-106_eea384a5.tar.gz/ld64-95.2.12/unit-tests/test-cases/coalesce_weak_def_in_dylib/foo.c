

__attribute__((weak)) void wfoo() {}
void foo() {}
