

void foo() 
{
   // do nothing
}
