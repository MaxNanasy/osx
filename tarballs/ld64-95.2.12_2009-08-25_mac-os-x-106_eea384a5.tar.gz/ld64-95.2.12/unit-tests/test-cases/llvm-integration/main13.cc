#include "a13.h"

int main()
{
  A a;
  a.foo();
  return 0;
}
