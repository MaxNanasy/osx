extern int foo4(void);
int foo3()
{
	return foo4();
}

