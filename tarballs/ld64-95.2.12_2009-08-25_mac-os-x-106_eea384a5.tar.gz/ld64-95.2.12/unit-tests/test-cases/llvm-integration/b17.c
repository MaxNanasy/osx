int b = 0;
int func_b() { return b; }


