extern int bar;
int foo2() {
	return bar;
}
