

#include "foo.h"

void foo1() {}
void foo2() {}
void foo3() {}
void foo4() {}

