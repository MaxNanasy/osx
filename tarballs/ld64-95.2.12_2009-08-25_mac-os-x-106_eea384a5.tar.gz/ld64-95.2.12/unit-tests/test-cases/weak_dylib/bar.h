

extern void bar1();
extern void bar2() __attribute__((weak_import));
extern void bar3();
extern void bar4() __attribute__((weak_import));



