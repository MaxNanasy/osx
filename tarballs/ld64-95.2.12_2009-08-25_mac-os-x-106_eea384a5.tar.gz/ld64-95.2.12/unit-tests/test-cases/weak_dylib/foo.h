

extern void foo1();
extern void foo2() __attribute__((weak_import));
extern void foo3();
extern void foo4() __attribute__((weak_import));
