#include <Foundation/Foundation.h>

@interface Baz : NSObject
@end

@implementation Baz
@end

