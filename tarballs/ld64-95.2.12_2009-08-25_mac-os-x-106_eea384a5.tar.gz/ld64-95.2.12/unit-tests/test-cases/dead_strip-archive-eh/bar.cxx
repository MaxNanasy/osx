
#include <stdio.h>

void doit()
{
	printf("hello there %s\n", "world");

}

void bar() 
{
	doit();
}

