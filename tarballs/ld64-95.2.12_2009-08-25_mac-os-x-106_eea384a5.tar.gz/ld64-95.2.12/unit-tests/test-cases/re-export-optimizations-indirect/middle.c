
void middle() {}

