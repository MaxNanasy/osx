


void bar1() {}
void bar2() {}


int bar_data1 = 0;
int bar_data2 = 0;
