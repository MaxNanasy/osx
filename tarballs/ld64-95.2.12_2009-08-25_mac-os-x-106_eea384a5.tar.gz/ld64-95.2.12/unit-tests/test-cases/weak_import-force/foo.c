


void foo1() {}
void foo2() {}


int foo_data1 = 0;
int foo_data2 = 0;
