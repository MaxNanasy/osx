
int __attribute__((visibility("hidden"))) foo = 0;

