#ifndef _NORM_CHARMAP_H_
#define _NORM_CHARMAP_H_

/* norm_charmap.c */
const char *norm_charmap(const char *name);

#endif
