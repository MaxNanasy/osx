#ifndef SDUMP_H
#define SDUMP_H

#include <stdlib.h>

char *sdump(const char *in, size_t len);

#endif
