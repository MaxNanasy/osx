<?php
function da_encrypt($passwd)
{
        return $passwd;
}
?>
