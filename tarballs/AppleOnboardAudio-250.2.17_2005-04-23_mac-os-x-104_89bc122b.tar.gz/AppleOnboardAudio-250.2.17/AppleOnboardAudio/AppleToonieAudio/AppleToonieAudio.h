/*
 *  AppleToonieAudio.h
 *  AppleOnboardAudio
 *
 *  Created by the Audio Team! on Wed Apr 14 2004.
 *  Copyright (c) 2004 AppleComputer, Inc. All rights reserved.
 *
 */

#include "AudioHardwareObjectInterface.h"
#include "PlatformInterface.h"
#include "AppleDBDMAAudio.h"
#include "AppleOnboardAudio.h"
#include "AppleOnboardAudioUserClient.h"


