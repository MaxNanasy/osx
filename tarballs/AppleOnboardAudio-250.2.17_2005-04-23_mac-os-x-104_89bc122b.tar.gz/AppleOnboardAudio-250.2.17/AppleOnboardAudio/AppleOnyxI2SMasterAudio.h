/*
 *  AppleOnyxAudio.h
 *  AppleOnboardAudio
 *
 *  Created by AudioSW Team on Friday 14 May 2004.
 *  Copyright (c) 2003 AppleComputer. All rights reserved.
 *
 */

#include "AudioHardwareObjectInterface.h"
#include "Onyx_hw.h"
#include "PlatformInterface.h"
#include "AppleDBDMAAudio.h"
#include "AppleOnboardAudio.h"
#include "AppleOnboardAudioUserClient.h"
#include "AppleOnyxAudio.h"


