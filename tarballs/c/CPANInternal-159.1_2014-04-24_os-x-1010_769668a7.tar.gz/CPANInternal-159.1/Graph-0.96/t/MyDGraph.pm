package DGraph;
require Graph::Directed;
@DGraph::ISA=qw(Graph::Directed);
1;
