package DBICTest::Schema::13::Foo;
our $skip_me = "bad mojo";
1;
