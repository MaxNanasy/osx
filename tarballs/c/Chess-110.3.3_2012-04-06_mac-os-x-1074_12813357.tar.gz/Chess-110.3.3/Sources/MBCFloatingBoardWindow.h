/*
	File:		MBCFloatingBoardWindow.h
	Contains:	The board window for the floating board
	Version:	1.0
	Copyright:	� 2003 by Apple Computer, Inc., all rights reserved.
*/

#import <Cocoa/Cocoa.h>

@interface MBCFloatingBoardWindow : NSWindow
{
}

@end

// Local Variables:
// mode:ObjC
// End:
