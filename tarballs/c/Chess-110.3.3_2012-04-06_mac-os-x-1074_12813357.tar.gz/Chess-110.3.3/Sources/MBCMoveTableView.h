//
//  MBCMoveTableView.h
//  MBChess
//
//  Created by Matthias Neeracher on 10/7/10.
//  Copyright 2010 Apple Computer. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface MBCMoveTableView : NSTableView {
	bool	fInGridDrawing;
}

@end
