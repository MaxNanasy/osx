//
//  dummy.c
//  coretls
//
//  Created by Fabrice Gautier on 1/3/14.
//
//

// need at least one .c file for the dylib.