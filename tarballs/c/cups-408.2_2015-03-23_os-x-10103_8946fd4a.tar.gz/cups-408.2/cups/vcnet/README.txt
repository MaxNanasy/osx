README - CUPS v1.7b1 - 2013-04-18
---------------------------------

INTRODUCTION

    This package includes the cupstestppd and ipptool utilities, CUPS API
    libraries libcups2.dll and libcupsimage2.dll, and the import libraries and
    headers needed to develop Windows applications that use the CUPS API to
    communicate with CUPS and other IPP services.

    See the file "IPPTOOL.txt" for instructions on using the ipptool utility.


LEGAL STUFF

    CUPS is Copyright 2007-2013 by Apple Inc.  CUPS and the CUPS logo are
    trademarks of Apple Inc.

    The MD5 Digest code is Copyright 1999 Aladdin Enterprises.

    This software is based in part on the work of the Independent JPEG Group.

    CUPS is provided under the terms of version 2 of the GNU General Public
    License and GNU Library General Public License. This program is distributed
    in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even
    the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the "doc/help/license.html" or "LICENSE.txt" files for more information.
