#ifndef __ITUNES_DATABASE_H__
#define __ITUNES_DATABASE_H__

#include "CDDATrackName.h"


