#ifndef DYLD_PREBIND_DEFS_H
#import <sys/time.h>

typedef char *data_t;
typedef struct timeval struct_timeval;
#define DYLD_PREBIND_DEFS_H
#endif
