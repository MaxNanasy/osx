package # Hide from PAUSE
    MyClass::Parent;

sub parent_method { return 'parent_method'; }

1;
