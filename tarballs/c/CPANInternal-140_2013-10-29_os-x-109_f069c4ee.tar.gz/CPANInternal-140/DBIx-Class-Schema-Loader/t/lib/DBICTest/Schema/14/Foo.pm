package DBICTest::Schema::14::Foo;
our $skip_me = "bad mojo";
1;
