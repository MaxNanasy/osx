package TestLeftBase;

sub test_additional_base_override { return "test_left_base_override"; }

1;
