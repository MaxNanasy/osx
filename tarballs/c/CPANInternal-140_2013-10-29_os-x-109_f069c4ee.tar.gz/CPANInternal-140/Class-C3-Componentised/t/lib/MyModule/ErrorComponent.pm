package # hide from PAUSE
    MyModule::ErrorComponent;
use warnings;
use strict;

# this is missing on purpose
# 1;

