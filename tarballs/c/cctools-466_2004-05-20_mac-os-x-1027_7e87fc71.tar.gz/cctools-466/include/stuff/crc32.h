__private_extern__ unsigned long crc32(
    const void *buf,
    unsigned int len);
