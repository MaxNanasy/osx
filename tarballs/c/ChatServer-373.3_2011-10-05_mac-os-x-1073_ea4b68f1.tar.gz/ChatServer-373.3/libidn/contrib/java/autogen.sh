#!/bin/sh -x
autoreconf --install --force --verbose
