#!/bin/sh
set -ex

chmod +x "${DSTROOT}"/private/etc/periodic/*/*
