/* Copyright (c) 2002-2011 Pigeonhole authors, see the included COPYING file
 */
 
#ifndef __SIEVE_EXT_DEBUG_H
#define __SIEVE_EXT_DEBUG_H

/*
 * Extension
 */
 
extern const struct sieve_extension_def debug_extension;

#endif /* __SIEVE_EXT_DEBUG_H */
