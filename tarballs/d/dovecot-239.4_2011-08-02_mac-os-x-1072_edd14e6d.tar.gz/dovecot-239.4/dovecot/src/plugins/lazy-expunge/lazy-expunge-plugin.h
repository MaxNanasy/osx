#ifndef LAZY_EXPUNGE_PLUGIN_H
#define LAZY_EXPUNGE_PLUGIN_H

void lazy_expunge_plugin_init(struct module *module);
void lazy_expunge_plugin_deinit(void);

#endif
