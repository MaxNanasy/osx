#ifndef LISTESCAPE_PLUGIN_H
#define LISTESCAPE_PLUGIN_H

void listescape_plugin_init(struct module *module);
void listescape_plugin_deinit(void);

#endif
