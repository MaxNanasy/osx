#ifndef SNARF_PLUGIN_H
#define SNARF_PLUGIN_H

void snarf_plugin_init(struct module *module);
void snarf_plugin_deinit(void);

#endif
