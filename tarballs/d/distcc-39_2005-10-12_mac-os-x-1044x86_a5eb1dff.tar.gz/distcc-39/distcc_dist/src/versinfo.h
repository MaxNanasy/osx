

char *dcc_get_compiler_version(char *compiler);
char **dcc_get_all_compiler_versions(void);
char *dcc_get_system_version(void);
int dcc_is_allowed_compiler(char *path);
