#ifndef BUILD_VERSION
#warning VERIFY BUILD_VERSION NUMBER BEFORE SUBMITTING!!
#define BUILD_VERSION "60.1"


#ifdef __cplusplus
extern "C" {
#endif

void dsToolAppleVersionExit( const char *toolName );
#ifdef __cplusplus
};
#endif

#endif
