#ifndef EXPIRE_PLUGIN_H
#define EXPIRE_PLUGIN_H

void expire_plugin_init(struct module *module);
void expire_plugin_deinit(void);

#endif
