extern void baz();

void bar()
{
	baz();
}


