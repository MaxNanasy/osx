

int bar[] = { 20, 21, 22, 23 };

// needs something weak to join coalescing fun
int __attribute__((weak)) junk = 5;
