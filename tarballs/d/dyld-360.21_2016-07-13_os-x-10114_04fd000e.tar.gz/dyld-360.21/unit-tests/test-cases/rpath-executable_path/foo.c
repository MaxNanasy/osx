

void foo()
{
}
