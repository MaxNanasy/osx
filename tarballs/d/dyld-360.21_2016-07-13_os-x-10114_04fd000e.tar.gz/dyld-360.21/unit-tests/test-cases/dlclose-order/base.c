#include "base.h"

bool barInitied   = false;
bool barTeminated = false;

bool bazInitied   = false;
bool bazTeminated = false;

