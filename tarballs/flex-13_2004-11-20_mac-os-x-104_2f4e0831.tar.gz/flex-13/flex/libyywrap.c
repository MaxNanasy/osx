/* libyywrap - flex run-time support library "yywrap" function */

/* $Header: /cvs/root/flex/flex/libyywrap.c,v 1.1.1.1 1999/04/23 00:46:30 wsanchez Exp $ */

int yywrap()
	{
	return 1;
	}
