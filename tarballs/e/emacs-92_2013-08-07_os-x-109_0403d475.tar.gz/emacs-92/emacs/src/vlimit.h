/* Dummy for Emacs so that we can run on VMS... */
#define LIM_DATA 0

/* arch-tag: 0c3436cb-5edc-447a-87af-acec402a65b9
   (do not change this comment) */
