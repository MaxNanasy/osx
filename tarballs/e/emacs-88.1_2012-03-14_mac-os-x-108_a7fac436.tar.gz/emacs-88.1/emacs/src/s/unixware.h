#include "usg5-4-2.h"

#define	PENDING_OUTPUT_COUNT(FILE) ((FILE)->__ptr - (FILE)->__base)

/* arch-tag: d82e92e7-9443-4a60-a581-7f293cbae8a3
   (do not change this comment) */
