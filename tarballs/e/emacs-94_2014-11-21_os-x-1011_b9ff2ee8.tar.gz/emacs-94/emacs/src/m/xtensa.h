/* Machine description file for Tensilica Xtensa.

Add a license notice if this grows to > 10 lines of code.  */

#define NO_ARG_ARRAY
#define NO_UNION_TYPE

#ifdef __LITTLE_ENDIAN
#undef WORDS_BIG_ENDIAN
#else
#define WORDS_BIG_ENDIAN
#endif

/* arch-tag: fe5872de-d565-4d81-8fe0-ea19865b3e6a
   (do not change this comment) */
