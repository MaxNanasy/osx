#include "vms.h"
#define VMS4_0

/* arch-tag: 734e1c69-d514-4441-bbcd-8b5db8ab1892
   (do not change this comment) */
