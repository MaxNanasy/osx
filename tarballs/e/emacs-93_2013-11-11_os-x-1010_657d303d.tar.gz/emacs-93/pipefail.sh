#!/bin/sh
exec /bin/sh -o pipefail "$@"
