/* Configuration file for the Pyramid machine that uses the MIPS cpu.  */
/* This does not fully work.  */

#include "m-pyramid.h"

#define SYSTEM_MALLOC
#define CANNOT_DUMP

/* arch-tag: 82559148-25a8-466d-bbb3-f903f7666b7a
   (do not change this comment) */
