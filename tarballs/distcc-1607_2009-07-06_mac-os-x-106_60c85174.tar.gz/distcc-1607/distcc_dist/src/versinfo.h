

char *dcc_get_compiler_version(char *compiler);
char **dcc_get_all_compiler_versions(void);
char *dcc_get_system_version(void);
char *dcc_get_allowed_compiler_for_path(char *path);
