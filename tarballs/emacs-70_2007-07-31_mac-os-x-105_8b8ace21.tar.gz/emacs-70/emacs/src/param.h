/* This is so that Emacs can run on VMS... */
#define EXEC_PAGESIZE 512

/* arch-tag: a6daea28-33a6-4dd3-97d8-5ee1a12f09d3
   (do not change this comment) */
