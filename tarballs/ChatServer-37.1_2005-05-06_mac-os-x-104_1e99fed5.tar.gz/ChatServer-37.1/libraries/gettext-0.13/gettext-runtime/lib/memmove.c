#include "../../gettext-tools/lib/memmove.c"
