extern int rpathy_value (void);
int main () { return !(rpathy_value () == 57); }
