/* $XFree86: xc/lib/GL/mesa/src/drv/ffb/ffb_stencil.h,v 1.1 2000/06/20 05:08:39 dawes Exp $ */

#ifndef _FFB_STENCIL_H
#define _FFB_STENCIL_H

extern void ffbDDInitStencilFuncs(GLcontext *ctx);

#endif /* !(_FFB_STENCIL_H) */
