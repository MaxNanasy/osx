/*
 *    Copyright (c) 2003, Derek Price, Ximbiot <http://ximbiot.com>,
 *                        and the Free Software Foundation
 *
 *    You may distribute under the terms of the GNU General Public License
 *    as specified in the README file that comes with the CVS source
 *    distribution.
 *
 * This is the header file for definitions and functions shared by history.c
 * with other portions of CVS.
 */

#define ALL_HISTORY_REC_TYPES "TOEFWUPCGMAR"
