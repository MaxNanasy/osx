/*
 *  global.h
 *  ifd-CCID
 *
 *  Created by JL on Mon Feb 10 2003.
 *  Copyright (c) 2003 Jean-Luc Giraud. All rights reserved.
 *  See COPYING file for license.
 */

#ifndef _GLOBAL_H_
#define _GLOBAL_H_

#define BUNDLE_IDENTIFIER "com.apple.ccidclassdriver"

#endif
