#ifndef COMP_H
#define COMP_H

#include <render.h>

extern graph_t** findCComp (graph_t*, int*, int*);

#endif
