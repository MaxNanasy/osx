/* $OpenBSD: version.h,v 1.73 2015/07/01 01:55:13 djm Exp $ */

#define SSH_VERSION	"OpenSSH_6.9"

#define SSH_PORTABLE	"p1"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE
