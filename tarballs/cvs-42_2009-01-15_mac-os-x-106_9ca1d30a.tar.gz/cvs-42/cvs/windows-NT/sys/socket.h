#ifndef SYS_SOCKET_H
#define SYS_SOCKET_H

#define WIN32_LEAN_AND_MEAN
#include <winsock2.h>

typedef size_t socklen_t;

#endif /* SYS_SOCKET_H */
