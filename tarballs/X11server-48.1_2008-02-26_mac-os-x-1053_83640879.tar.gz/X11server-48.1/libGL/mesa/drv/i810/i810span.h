#ifndef _I810_SPAN_H
#define _I810_SPAN_H

extern void i810InitSpanFuncs( GLcontext *ctx );

#endif
