#ifndef R200_SANITY_H
#define R200_SANITY_H

extern int r200SanityCmdBuffer( r200ContextPtr rmesa,
				int nbox,
				XF86DRIClipRectRec *boxes );

#endif
