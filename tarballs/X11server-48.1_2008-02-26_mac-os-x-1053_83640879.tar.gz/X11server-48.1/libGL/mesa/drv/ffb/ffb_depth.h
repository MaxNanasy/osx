/* $XFree86: xc/lib/GL/mesa/src/drv/ffb/ffb_depth.h,v 1.1 2000/06/20 05:08:38 dawes Exp $ */

#ifndef _FFB_DEPTH_H
#define _FFB_DEPTH_H

extern void ffbDDInitDepthFuncs(GLcontext *ctx);

#endif /* !(_FFB_DEPTH_H) */
