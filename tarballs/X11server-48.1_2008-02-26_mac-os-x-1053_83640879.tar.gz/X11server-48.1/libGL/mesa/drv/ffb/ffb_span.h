/* $XFree86: xc/lib/GL/mesa/src/drv/ffb/ffb_span.h,v 1.1 2000/06/20 05:08:39 dawes Exp $ */

#ifndef _FFB_SPAN_H
#define _FFB_SPAN_H

extern void ffbDDInitSpanFuncs(GLcontext *ctx);

#endif /* !(_FFB_SPAN_H) */
