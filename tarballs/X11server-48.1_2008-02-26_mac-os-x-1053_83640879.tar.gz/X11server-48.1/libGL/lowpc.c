/*
 * This is the lowest address in Mesa
 */
void glx_lowpc(void) { }
