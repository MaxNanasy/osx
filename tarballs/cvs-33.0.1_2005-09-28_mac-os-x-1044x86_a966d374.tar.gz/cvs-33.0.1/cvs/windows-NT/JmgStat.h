#ifndef JMGSTAT_H
# define JMGSTAT_H
BOOL GetUTCFileModTime ( LPCTSTR name, time_t * utc_mod_time );
#endif /* !JMGSTAT_H */
