#ifndef WebCore_FWD_ByteArray_h
#define WebCore_FWD_ByteArray_h
#include <JavaScriptCore/ByteArray.h>
#endif
