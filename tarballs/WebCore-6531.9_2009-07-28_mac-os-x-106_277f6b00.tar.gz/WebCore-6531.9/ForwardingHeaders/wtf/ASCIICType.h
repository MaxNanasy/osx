#ifndef WebCore_FWD_ASCIICType_h
#define WebCore_FWD_ASCIICType_h
#include <JavaScriptCore/ASCIICType.h>
#endif
