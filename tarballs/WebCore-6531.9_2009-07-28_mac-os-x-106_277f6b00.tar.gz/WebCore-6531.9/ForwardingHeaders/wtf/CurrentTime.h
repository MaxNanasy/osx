#ifndef WebCore_FWD_CurrentTime_h
#define WebCore_FWD_CurrentTime_h
#include <JavaScriptCore/CurrentTime.h>
#endif
