#ifndef WebCore_FWD_HashMap_h
#define WebCore_FWD_HashMap_h
#include <JavaScriptCore/HashMap.h>
#endif
