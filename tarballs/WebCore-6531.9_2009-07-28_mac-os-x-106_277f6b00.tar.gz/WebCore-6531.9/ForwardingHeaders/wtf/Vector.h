#ifndef WebCore_FWD_Vector_h
#define WebCore_FWD_Vector_h
#include <JavaScriptCore/Vector.h>
#endif
