#ifndef WebCore_FWD_VMTags_h
#define WebCore_FWD_VMTags_h
#include <JavaScriptCore/VMTags.h>
#endif
