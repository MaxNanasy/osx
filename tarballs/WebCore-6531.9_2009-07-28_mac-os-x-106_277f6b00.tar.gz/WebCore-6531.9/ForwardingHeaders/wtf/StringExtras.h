#ifndef WebCore_FWD_StringExtras_h
#define WebCore_FWD_StringExtras_h
#include <JavaScriptCore/StringExtras.h>
#endif
