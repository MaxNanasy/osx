#ifndef WebCore_FWD_MessageQueue_h
#define WebCore_FWD_MessageQueue_h
#include <JavaScriptCore/MessageQueue.h>
#endif
