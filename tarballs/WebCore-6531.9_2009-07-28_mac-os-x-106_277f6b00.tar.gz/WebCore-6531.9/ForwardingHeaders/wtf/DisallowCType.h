#ifndef WebCore_FWD_DisallowCType_h
#define WebCore_FWD_DisallowCType_h
#include <JavaScriptCore/DisallowCType.h>
#endif
