#ifndef WebCore_FWD_RetainPtr_h
#define WebCore_FWD_RetainPtr_h
#include <JavaScriptCore/RetainPtr.h>
#endif
