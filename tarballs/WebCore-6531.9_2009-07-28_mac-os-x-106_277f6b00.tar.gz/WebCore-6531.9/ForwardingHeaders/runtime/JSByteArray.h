#ifndef WebCore_FWD_JSByteArray_h
#define WebCore_FWD_JSByteArray_h
#include <JavaScriptCore/JSByteArray.h>
#endif
