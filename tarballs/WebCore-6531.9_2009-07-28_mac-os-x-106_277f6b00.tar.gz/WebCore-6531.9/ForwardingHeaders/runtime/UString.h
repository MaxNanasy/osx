#ifndef WebCore_FWD_UString_h
#define WebCore_FWD_UString_h
#include <JavaScriptCore/UString.h>
#endif
