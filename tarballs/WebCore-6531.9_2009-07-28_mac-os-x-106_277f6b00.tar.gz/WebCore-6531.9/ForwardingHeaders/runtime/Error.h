#ifndef WebCore_FWD_Error_h
#define WebCore_FWD_Error_h
#include <JavaScriptCore/Error.h>
#endif
