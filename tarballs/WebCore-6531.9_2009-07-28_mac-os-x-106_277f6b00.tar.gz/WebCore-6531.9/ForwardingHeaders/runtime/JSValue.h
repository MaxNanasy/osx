#ifndef WebCore_FWD_JSValue_h
#define WebCore_FWD_JSValue_h
#include <JavaScriptCore/JSValue.h>
#endif
