#ifndef WebCore_FWD_CollectorHeapIterator_h
#define WebCore_FWD_CollectorHeapIterator_h
#include <JavaScriptCore/CollectorHeapIterator.h>
#endif
