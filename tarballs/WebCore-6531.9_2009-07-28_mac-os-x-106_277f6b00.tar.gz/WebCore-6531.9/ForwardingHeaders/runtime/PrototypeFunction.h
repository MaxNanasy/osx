#ifndef WebCore_FWD_PrototypeFunction_h
#define WebCore_FWD_PrototypeFunction_h
#include <JavaScriptCore/PrototypeFunction.h>
#endif

