#ifndef WebCore_FWD_FunctionPrototype_h
#define WebCore_FWD_FunctionPrototype_h
#include <JavaScriptCore/FunctionPrototype.h>
#endif
