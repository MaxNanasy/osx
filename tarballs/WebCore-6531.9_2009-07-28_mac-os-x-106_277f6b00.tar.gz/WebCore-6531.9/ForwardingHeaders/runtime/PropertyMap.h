#ifndef WebCore_FWD_PropertyMap_h
#define WebCore_FWD_PropertyMap_h
#include <JavaScriptCore/PropertyMap.h>
#endif

