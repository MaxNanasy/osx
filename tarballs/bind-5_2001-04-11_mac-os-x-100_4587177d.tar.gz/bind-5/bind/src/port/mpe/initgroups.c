#include <sys/types.h>

int __bind_mpe_initgroups(char *name, gid_t basegid) {

return 0;
}
