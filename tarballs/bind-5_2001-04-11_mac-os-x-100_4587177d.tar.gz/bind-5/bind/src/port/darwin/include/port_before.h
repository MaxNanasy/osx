#define WANT_IRS_NIS
#define WANT_IRS_PW
#define SIG_FN void
#define ts_sec tv_sec
#define ts_nsec tv_nsec
#define __BIND_RES_TEXT
