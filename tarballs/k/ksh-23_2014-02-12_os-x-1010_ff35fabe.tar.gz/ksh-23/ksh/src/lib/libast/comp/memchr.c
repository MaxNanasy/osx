/***********************************************************************
*                                                                      *
*               This software is part of the ast package               *
*          Copyright (c) 1985-2011 AT&T Intellectual Property          *
*                      and is licensed under the                       *
*                 Eclipse Public License, Version 1.0                  *
*                    by AT&T Intellectual Property                     *
*                                                                      *
*                A copy of the License is available at                 *
*          http://www.eclipse.org/org/documents/epl-v10.html           *
*         (with md5 checksum b35adb5213ca9657e911e9befb180842)         *
*                                                                      *
*              Information and Software Systems Research               *
*                            AT&T Research                             *
*                           Florham Park NJ                            *
*                                                                      *
*                 Glenn Fowler <gsf@research.att.com>                  *
*                  David Korn <dgk@research.att.com>                   *
*                   Phong Vo <kpv@research.att.com>                    *
*                                                                      *
***********************************************************************/
#pragma prototyped

#include <ast.h>

#if _lib_memchr

NoN(memchr)

#else

/*
 * Return the ptr in sp at which the character c appears;
 * 0 if not found in n chars; don't stop at \0.
 */

void*
memchr(const void* asp, register int c, size_t n)
{
	register const char*	sp = (char*)asp;
	register const char*	ep = sp + n;

	while (sp < ep)
		if (*sp++ == c)
			return(--sp);
	return(0);
}

#endif
