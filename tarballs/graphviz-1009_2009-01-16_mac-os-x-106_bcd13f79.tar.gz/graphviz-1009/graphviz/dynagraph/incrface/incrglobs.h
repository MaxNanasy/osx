// globals in incrcmds.cpp
extern Transform *g_transform; 
extern bool g_dotCoords;
