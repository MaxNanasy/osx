extern void XineramifyXv(void);
