#define MROP 0
#include "../cfb/cfbblt.c"
