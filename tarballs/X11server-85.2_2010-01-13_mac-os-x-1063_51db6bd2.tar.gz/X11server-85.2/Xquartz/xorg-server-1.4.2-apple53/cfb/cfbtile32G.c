#define MROP 0
#include "../cfb/cfbtile32.c"
