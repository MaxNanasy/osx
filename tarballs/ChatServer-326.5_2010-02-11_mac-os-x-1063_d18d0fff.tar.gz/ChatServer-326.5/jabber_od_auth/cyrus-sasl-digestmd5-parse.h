/*
 *  cyrus-sasl-digestmd5-parse.h
 *
 *  korver@apple.com
 *
 *  Copyright (c) 2009, Apple Inc. All rights reserved.
 */

#ifndef __CYRUS_SASL_DIGESTMD5_PARSE_H__
#define __CYRUS_SASL_DIGESTMD5_PARSE_H__

void ODKGetPair(char **in, char **name, char **value);

#endif
