function customStartup() {

}
