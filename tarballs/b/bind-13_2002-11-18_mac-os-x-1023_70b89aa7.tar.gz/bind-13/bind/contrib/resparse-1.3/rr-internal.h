extern void free_rr(s_rr *rrp);
extern void free_response(res_response *resp);
