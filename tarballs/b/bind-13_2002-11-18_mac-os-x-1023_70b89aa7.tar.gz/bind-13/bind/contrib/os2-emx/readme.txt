The files in this directory are:

	readme.txt	you're reading it
	diffs.txt	context diffs to add OS/2 (EMX) portability
	newfiles.zip	new files nec'y to add OS/2 (EMX) portability

These files were distilled from the public domain port of BIND to OS/2 (EMX)
done and contributed by <webmaster@very.priv.at>.  You should read the various
documents contained in newfiles.zip (which should be unzipped at the top of
the BIND source directory tree) to learn what it does and how to use it.
