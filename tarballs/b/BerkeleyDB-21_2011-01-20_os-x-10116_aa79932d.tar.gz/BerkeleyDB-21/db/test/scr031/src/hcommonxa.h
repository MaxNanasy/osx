#ifndef HCOMMONXA_H
#define	HCOMMONXA_H

#define	HERR_SYS_CUR 102
#define	HERR_TUX_CUR 103
#define	HERR_FML_CUR 104

#endif
