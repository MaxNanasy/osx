/*	fname	fldid            */
/*	-----	-----            */
#define	SEQ_NO	((FLDID32)33554833)	/* number: 401	 type: long */
#define	TS_SEC	((FLDID32)33554834)	/* number: 402	 type: long */
#define	TS_USEC	((FLDID32)33554835)	/* number: 403	 type: long */
