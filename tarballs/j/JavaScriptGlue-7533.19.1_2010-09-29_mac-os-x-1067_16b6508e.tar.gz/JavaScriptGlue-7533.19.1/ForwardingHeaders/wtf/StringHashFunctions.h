#include <JavaScriptCore/StringHashFunctions.h>
