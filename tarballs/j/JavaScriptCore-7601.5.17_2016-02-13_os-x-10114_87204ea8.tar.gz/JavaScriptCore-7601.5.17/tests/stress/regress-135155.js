function run() {
    for (var t = 1, i = 0; i < 10000; t++, i++) {
        t.length = function() {
            var foo = iv.charCodeAt(foo, undefined);
        };
    }
}

run();
