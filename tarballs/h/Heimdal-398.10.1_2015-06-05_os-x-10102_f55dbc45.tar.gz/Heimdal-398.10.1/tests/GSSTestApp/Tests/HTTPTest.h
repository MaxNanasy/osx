//
//  HTTPTest.h
//  GSSTestApp
//
//  Created by Love Hörnquist Åstrand on 2013-06-09.
//  Copyright (c) 2013 Apple, Inc. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface HTTPTest : SenTestCase

@end
