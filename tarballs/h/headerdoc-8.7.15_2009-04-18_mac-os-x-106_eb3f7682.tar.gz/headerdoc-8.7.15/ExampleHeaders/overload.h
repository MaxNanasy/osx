/*! @class overload_test
*/

class overload_test
{
/*! @function function
    @param a integer
 */
    static int function(int a);

/*! @function function
    @param a string
    @param b integer
 */
    const char function(char *a, int b);

}

