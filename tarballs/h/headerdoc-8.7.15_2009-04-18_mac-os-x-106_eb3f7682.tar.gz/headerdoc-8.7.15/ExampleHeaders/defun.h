

/*! @function foo_define_001
	@param a arg1
	@param b arg2
 */

#define foo_define_001(a, b) { printf(a, b) }

/*! @function bar_define_001
	@param c arg3
	@param d arg4
 */

#define bar_define_001(c, d) { \
	printf(c, d) \
	}

