//
//  ViewController.h
//  GSSSimpleTest
//
//  Copyright (c) 2013 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (assign) IBOutlet UITextField *url;
@property (assign) IBOutlet UIWebView *result;

@end
