//
//  TestUsers.m
//  GSSTestApp
//
//  Created by Love Hörnquist Åstrand on 2014-02-16.
//  Copyright (c) 2014 Apple, Inc. All rights reserved.
//

#import "TestUsers.h"

NSString *passwordKtestuserQAD =
    @"not in clear"
;
