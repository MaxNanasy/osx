//
//  DumpCacheViewController.h
//  GSSTestApp
//
//  Created by Love Hörnquist Åstrand on 2014-09-03.
//  Copyright (c) 2014 Apple, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DumpCacheViewController : UIViewController
@property (weak) IBOutlet UITextView *dumpCacheTextView;
@end
