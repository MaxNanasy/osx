/*! @header foo.h
    @availability 10.2 and later
    @discussion foo discussion
    @cfbundleidentifier com.mycompany.mybundle
 */

/*! @function bar 
    @availability 10.3 and later
 */
void bar(int a);

