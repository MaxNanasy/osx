/* $XFree86$ */

extern void XineramifyXv(void);
