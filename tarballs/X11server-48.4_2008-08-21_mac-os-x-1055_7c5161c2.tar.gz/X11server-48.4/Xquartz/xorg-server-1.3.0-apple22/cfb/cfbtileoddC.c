#define MROP Mcopy
#include "../cfb/cfbtileodd.c"
