#define RROP GXxor
#include "../cfb/cfbzerarc.c"
