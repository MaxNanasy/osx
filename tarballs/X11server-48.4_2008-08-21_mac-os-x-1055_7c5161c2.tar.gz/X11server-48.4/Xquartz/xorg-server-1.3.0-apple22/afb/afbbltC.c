#define MROP Mcopy
#include "./afbblt.c"
