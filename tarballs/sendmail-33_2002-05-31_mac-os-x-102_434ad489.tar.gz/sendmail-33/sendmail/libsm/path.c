/*
 * Copyright (c) 2000-2001 Sendmail, Inc. and its suppliers.
 *	All rights reserved.
 *
 * By using this file, you agree to the terms and conditions set
 * forth in the LICENSE file which can be found at the top level of
 * the sendmail distribution.
 */

#include <sm/gen.h>
SM_RCSID("@(#)$Id: path.c,v 1.1.1.1 2002/03/12 18:00:20 zarzycki Exp $")

#include <sm/path.h>
#include <sm/string.h>

