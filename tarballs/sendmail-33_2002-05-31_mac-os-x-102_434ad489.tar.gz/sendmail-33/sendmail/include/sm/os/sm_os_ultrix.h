/*
 * Copyright (c) 2001 Sendmail, Inc. and its suppliers.
 *	All rights reserved.
 *
 * By using this file, you agree to the terms and conditions set
 * forth in the LICENSE file which can be found at the top level of
 * the sendmail distribution.
 *
 *	$Id: sm_os_ultrix.h,v 1.1.1.1 2002/03/12 18:00:16 zarzycki Exp $
 */

/*
**  platform definitions for Ultrix
*/

#define SM_OS_NAME "ultrix"

#define SM_CONF_SSIZE_T	0
