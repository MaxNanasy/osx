#include <config.h>
#include "ntpdc.h"
#include "ntp_request.h"
