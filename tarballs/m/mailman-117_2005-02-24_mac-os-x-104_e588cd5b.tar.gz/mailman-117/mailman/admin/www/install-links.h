<!-- -*- html -*- -->
<h3>Installing Mailman</h3>
<li><a href="install-start.html">Start installing</a>
<li><a href="install-system.html">System setup</a>
<li><a href="install-config.html">Running configure</a>
<li><a href="install-check.html">Check your installation</a>
<li><a href="install-final.html">Final system setup</a>
<li><a href="install-custom.html">Customize Mailman</a>
<li><a href="install-test.html">Create a test list</a>
<li><a href="install-trouble.html">Troubleshooting</a>
<li><a href="install-faq.html">Common problems FAQ</a>
