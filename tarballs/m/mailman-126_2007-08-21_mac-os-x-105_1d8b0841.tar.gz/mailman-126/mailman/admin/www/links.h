<!-- -*- html -*- -->
<h3>Overview</h3>
<li><a href="index.html">Home</a></li>
<li><a href="security.html">Security</li>
<li><a href="features.html">Features</a></li>
<h3>More Information</h3>
<li><a href="http://wiki.list.org">Wiki</a> <i>(exit)</i></li>
<li><a href="lists.html">Discussion Lists</a></li>
<li><a href="http://sf.net/projects/mailman">SF Project Page</a>
    <i>(exit)</i></li>
<li><a href="otherstuff.html">Rants, Papers, and Logos</a></li>
<li><a href="bugs.html">Bugs and Patches</a></li>
<li><a href="mirrors.html">Mirrors</a></li>
