%internal_labels = ();
1;             # hack in case there are no entries

