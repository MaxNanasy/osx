#ifndef WebCore_FWD_UStringBuilder_h
#define WebCore_FWD_UStringBuilder_h
#include <JavaScriptCore/UStringBuilder.h>
#endif
