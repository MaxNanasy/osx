#ifndef WebCore_FWD_RegExpObject_h
#define WebCore_FWD_RegExpObject_h
#include <JavaScriptCore/RegExpObject.h>
#endif
