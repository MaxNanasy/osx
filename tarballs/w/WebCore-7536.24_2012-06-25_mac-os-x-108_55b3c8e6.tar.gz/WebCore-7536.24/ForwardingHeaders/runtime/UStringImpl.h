#ifndef WebCore_FWD_UStringImpl_h
#define WebCore_FWD_UStringImpl_h
#include <JavaScriptCore/UStringImpl.h>
#endif
