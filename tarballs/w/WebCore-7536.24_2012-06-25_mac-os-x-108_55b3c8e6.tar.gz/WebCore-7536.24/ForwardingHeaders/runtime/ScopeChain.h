#ifndef WebCore_FWD_ScopeChain_h
#define WebCore_FWD_ScopeChain_h
#include <JavaScriptCore/ScopeChain.h>
#endif
