#ifndef WebCore_FWD_YarrInterpreter_h
#define WebCore_FWD_YarrInterpreter_h
#include <JavaScriptCore/YarrInterpreter.h>
#endif

