#ifndef WebCore_FWD_InjectedScript_h
#define WebCore_FWD_InjectedScript_h
#include <JavaScriptCore/InjectedScript.h>
#endif
