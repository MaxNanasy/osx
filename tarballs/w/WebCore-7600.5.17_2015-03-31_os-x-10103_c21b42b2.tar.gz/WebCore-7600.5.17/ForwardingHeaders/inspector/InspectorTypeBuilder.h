#ifndef WebCore_FWD_InspectorTypeBuilder_h
#define WebCore_FWD_InspectorTypeBuilder_h
#include <JavaScriptCore/InspectorTypeBuilder.h>
#endif
