#ifndef WebCore_FWD_InjectedScriptBase_h
#define WebCore_FWD_InjectedScriptBase_h
#include <JavaScriptCore/InjectedScriptBase.h>
#endif
