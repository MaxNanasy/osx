#ifndef WebCore_FWD_InjectedScriptManager_h
#define WebCore_FWD_InjectedScriptManager_h
#include <JavaScriptCore/InjectedScriptManager.h>
#endif
