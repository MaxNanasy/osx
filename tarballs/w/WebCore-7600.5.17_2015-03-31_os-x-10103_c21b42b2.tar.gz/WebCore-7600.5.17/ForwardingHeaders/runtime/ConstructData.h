#ifndef WebCore_FWD_ConstructData_h
#define WebCore_FWD_ConstructData_h
#include <JavaScriptCore/ConstructData.h>
#endif
