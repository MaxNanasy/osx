#ifndef WebCore_FWD_IdentifierInlines_h
#define WebCore_FWD_IdentifierInlines_h
#include <JavaScriptCore/IdentifierInlines.h>
#endif
