#ifndef WebCore_FWD_JSPromise_h
#define WebCore_FWD_JSPromise_h
#include <JavaScriptCore/JSPromise.h>
#endif
