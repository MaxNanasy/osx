#ifndef WebCore_FWD_VMEntryScope_h
#define WebCore_FWD_VMEntryScope_h
#include <JavaScriptCore/VMEntryScope.h>
#endif
