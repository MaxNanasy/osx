#ifndef WebCore_FWD_LegacyProfiler_h
#define WebCore_FWD_LegacyProfiler_h
#include <JavaScriptCore/LegacyProfiler.h>
#endif

