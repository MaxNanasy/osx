#ifndef WebCore_FWD_CardSet_h
#define WebCore_FWD_CardSet_h
#include <JavaScriptCore/CardSet.h>
#endif
