#ifndef WebCore_FWD_Interpreter_h
#define WebCore_FWD_Interpreter_h
#include <JavaScriptCore/Interpreter.h>
#endif
