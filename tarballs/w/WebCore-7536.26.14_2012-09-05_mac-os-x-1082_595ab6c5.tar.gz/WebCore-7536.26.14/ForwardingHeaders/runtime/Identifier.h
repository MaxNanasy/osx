#ifndef WebCore_FWD_Identifier_h
#define WebCore_FWD_Identifier_h
#include <JavaScriptCore/Identifier.h>
#endif
