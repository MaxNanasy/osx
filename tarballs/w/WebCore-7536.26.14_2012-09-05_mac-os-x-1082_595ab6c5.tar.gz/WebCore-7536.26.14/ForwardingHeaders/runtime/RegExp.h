#ifndef WebCore_FWD_RegExp_h
#define WebCore_FWD_RegExp_h
#include <JavaScriptCore/RegExp.h>
#endif
