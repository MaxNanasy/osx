#ifndef WebCore_FWD_JSGlobalThis_h
#define WebCore_FWD_JSGlobalThis_h
#include <JavaScriptCore/JSGlobalThis.h>
#endif
