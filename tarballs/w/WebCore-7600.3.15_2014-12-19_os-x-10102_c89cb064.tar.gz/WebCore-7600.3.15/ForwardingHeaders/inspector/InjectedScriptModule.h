#ifndef WebCore_FWD_InjectedScriptModule_h
#define WebCore_FWD_InjectedScriptModule_h
#include <JavaScriptCore/InjectedScriptModule.h>
#endif
