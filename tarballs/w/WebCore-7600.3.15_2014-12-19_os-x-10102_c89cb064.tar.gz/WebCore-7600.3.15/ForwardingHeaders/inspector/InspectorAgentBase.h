#ifndef WebCore_FWD_InspectorAgentBase_h
#define WebCore_FWD_InspectorAgentBase_h
#include <JavaScriptCore/InspectorAgentBase.h>
#endif
