#ifndef WebCore_FWD_InspectorProfilerAgent_h
#define WebCore_FWD_InspectorProfilerAgent_h
#include <JavaScriptCore/InspectorProfilerAgent.h>
#endif
