#ifndef WebCore_FWD_YarrJIT_h
#define WebCore_FWD_YarrJIT_h
#include <JavaScriptCore/YarrJIT.h>
#endif

