#ifndef WebCore_FWD_BooleanObject_h
#define WebCore_FWD_BooleanObject_h
#include <JavaScriptCore/BooleanObject.h>
#endif
