#ifndef WebCore_FWD_IntegralTypedArrayBase_h
#define WebCore_FWD_IntegralTypedArrayBase_h
#include <JavaScriptCore/IntegralTypedArrayBase.h>
#endif
