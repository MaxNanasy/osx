#ifndef WebCore_FWD_SymbolTable_h
#define WebCore_FWD_SymbolTable_h
#include <JavaScriptCore/SymbolTable.h>
#endif
