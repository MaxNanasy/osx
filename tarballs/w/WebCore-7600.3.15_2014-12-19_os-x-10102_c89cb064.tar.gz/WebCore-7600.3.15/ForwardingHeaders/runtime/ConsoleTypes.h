#ifndef WebCore_FWD_ConsoleTypes_h
#define WebCore_FWD_ConsoleTypes_h
#include <JavaScriptCore/ConsoleTypes.h>
#endif
