#ifndef WebCore_FWD_JSWithScope_h
#define WebCore_FWD_JSWithScope_h
#include <JavaScriptCore/JSWithScope.h>
#endif
