#ifndef WebCore_FWD_NondeterministicInput_h
#define WebCore_FWD_NondeterministicInput_h
#include <JavaScriptCore/NondeterministicInput.h>
#endif
