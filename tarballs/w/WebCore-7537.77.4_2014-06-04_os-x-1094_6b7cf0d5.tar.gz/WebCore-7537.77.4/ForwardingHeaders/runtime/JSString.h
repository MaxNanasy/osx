#ifndef WebCore_FWD_JSString_h
#define WebCore_FWD_JSString_h
#include <JavaScriptCore/JSString.h>
#endif
