#ifndef WebCore_FWD_CallFrame_h
#define WebCore_FWD_CallFrame_h
#include <JavaScriptCore/CallFrame.h>
#endif
