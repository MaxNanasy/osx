#ifndef WebCore_FWD_WREC_h
#define WebCore_FWD_WREC_h
#include <JavaScriptCore/WREC.h>
#endif
