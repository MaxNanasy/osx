#ifndef WebCore_FWD_StringHash_h
#define WebCore_FWD_StringHash_h
#include <JavaScriptCore/StringHash.h>
#endif
