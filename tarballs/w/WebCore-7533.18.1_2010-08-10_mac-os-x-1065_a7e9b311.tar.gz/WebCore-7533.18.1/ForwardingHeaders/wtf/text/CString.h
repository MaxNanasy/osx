#ifndef WebCore_FWD_CString_h
#define WebCore_FWD_CString_h
#include <JavaScriptCore/CString.h>
#endif
