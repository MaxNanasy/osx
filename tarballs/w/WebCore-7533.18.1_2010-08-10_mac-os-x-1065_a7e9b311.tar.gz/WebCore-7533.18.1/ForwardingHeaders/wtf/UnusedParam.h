#ifndef WebCore_FWD_UnusedParam_h
#define WebCore_FWD_UnusedParam_h
#include <JavaScriptCore/UnusedParam.h>
#endif
