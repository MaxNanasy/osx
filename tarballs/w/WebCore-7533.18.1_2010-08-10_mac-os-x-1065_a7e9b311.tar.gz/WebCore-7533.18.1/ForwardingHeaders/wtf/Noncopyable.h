#ifndef WebCore_FWD_Noncopyable_h
#define WebCore_FWD_Noncopyable_h
#include <JavaScriptCore/Noncopyable.h>
#endif
