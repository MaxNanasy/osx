#ifndef WebCore_FWD_HashFunctions_h
#define WebCore_FWD_HashFunctions_h
#include <JavaScriptCore/HashFunctions.h>
#endif
