#ifndef WebCore_FWD_WTFThreadData_h
#define WebCore_FWD_WTFThreadData_h
#include <JavaScriptCore/WTFThreadData.h>
#endif
