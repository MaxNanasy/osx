#ifndef WebCore_FWD_PassRefPtr_h
#define WebCore_FWD_PassRefPtr_h
#include <JavaScriptCore/PassRefPtr.h>
#endif
