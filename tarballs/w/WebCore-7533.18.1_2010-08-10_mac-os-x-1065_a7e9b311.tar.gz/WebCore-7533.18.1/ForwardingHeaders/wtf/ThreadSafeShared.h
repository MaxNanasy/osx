#ifndef WebCore_FWD_ThreadSafeShared_h
#define WebCore_FWD_ThreadSafeShared_h
#include <JavaScriptCore/ThreadSafeShared.h>
#endif
