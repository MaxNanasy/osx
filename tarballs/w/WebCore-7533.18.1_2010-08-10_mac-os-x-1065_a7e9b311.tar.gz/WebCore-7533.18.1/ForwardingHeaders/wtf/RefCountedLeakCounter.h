#ifndef WebCore_FWD_RefCountedLeakCounter_h
#define WebCore_FWD_RefCountedLeakCounter_h
#include <JavaScriptCore/RefCountedLeakCounter.h>
#endif

