#ifndef WebCore_FWD_MD5_h
#define WebCore_FWD_MD5_h
#include <JavaScriptCore/MD5.h>
#endif

