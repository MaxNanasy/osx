#ifndef WebCore_FWD_DateInstanceCache_h
#define WebCore_FWD_DateInstanceCache_h
#include <JavaScriptCore/DateInstanceCache.h>
#endif
