#ifndef WebCore_FWD_Atomics_h
#define WebCore_FWD_Atomics_h
#include <JavaScriptCore/Atomics.h>
#endif
