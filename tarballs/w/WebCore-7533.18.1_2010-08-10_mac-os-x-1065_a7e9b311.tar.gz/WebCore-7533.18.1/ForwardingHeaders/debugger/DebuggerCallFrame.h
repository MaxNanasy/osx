#ifndef WebCore_FWD_DebuggerCallFrame_h
#define WebCore_FWD_DebuggerCallFrame_h
#include <JavaScriptCore/DebuggerCallFrame.h>
#endif
