#ifndef WebCore_FWD_Protect_h
#define WebCore_FWD_Protect_h
#include <JavaScriptCore/Protect.h>
#endif

