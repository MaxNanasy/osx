#ifndef WebCore_FWD_RopeImpl_h
#define WebCore_FWD_RopeImpl_h
#include <JavaScriptCore/RopeImpl.h>
#endif
