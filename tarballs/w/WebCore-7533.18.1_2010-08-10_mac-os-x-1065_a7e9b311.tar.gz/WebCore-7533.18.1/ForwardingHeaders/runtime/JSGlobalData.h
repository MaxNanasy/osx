#ifndef WebCore_FWD_JSGlobalData_h
#define WebCore_FWD_JSGlobalData_h
#include <JavaScriptCore/JSGlobalData.h>
#endif
