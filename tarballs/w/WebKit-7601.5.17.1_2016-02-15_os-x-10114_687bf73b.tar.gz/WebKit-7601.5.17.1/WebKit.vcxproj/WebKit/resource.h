//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by WebKit.rc
//
#define IDR_WEBKIT                      1
#define IDR_RESIZE_CORNER               2
#define IDR_MISSING_IMAGE               3
#define IDR_URL_ICON                    4
#define IDR_NULL_PLUGIN                 5
#define IDR_ZOOM_IN_CURSOR              6
#define IDR_ZOOM_OUT_CURSOR             7
#define IDR_VERTICAL_TEXT_CURSOR        8
#define IDR_PAN_SCROLL_ICON             9
#define IDR_PAN_SOUTH_CURSOR            10
#define IDR_PAN_NORTH_CURSOR            11
#define IDR_PAN_EAST_CURSOR             12
#define IDR_PAN_WEST_CURSOR             13
#define IDR_PAN_SOUTH_EAST_CURSOR       14
#define IDR_PAN_SOUTH_WEST_CURSOR       15
#define IDR_PAN_NORTH_EAST_CURSOR       16
#define IDR_PAN_NORTH_WEST_CURSOR       17
#define IDR_SEARCH_CANCEL               18
#define IDR_SEARCH_CANCEL_PRESSED       19
#define IDR_SEARCH_MAGNIFIER            20
#define IDR_SEARCH_MAGNIFIER_RESULTS    21
#define IDR_FS_VIDEO_AUDIO_VOLUME_HIGH  22
#define IDR_FS_VIDEO_AUDIO_VOLUME_LOW   23
#define IDR_FS_VIDEO_EXIT_FULLSCREEN    24
#define IDR_FS_VIDEO_PAUSE              25
#define IDR_FS_VIDEO_PLAY               26
#define IDC_STATIC                      -1

#define BUILD_NUMBER                    1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        22
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
