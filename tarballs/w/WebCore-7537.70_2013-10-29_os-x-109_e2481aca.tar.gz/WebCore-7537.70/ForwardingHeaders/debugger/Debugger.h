#ifndef WebCore_FWD_Debugger_h
#define WebCore_FWD_Debugger_h
#include <JavaScriptCore/Debugger.h>
#endif
