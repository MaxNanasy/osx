#ifndef WebCore_FWD_PassWeak_h
#define WebCore_FWD_PassWeak_h
#include <JavaScriptCore/PassWeak.h>
#endif
