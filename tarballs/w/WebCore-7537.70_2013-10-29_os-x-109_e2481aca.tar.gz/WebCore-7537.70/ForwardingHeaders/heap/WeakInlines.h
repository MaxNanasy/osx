#ifndef WebCore_FWD_WeakInlines_h
#define WebCore_FWD_WeakInlines_h
#include <JavaScriptCore/WeakInlines.h>
#endif
