#ifndef WebCore_FWD_JSExportMacros_h
#define WebCore_FWD_JSExportMacros_h
#include <JavaScriptCore/JSExportMacros.h>
#endif
