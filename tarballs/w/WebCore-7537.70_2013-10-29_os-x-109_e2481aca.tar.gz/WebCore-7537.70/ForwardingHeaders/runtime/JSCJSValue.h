#ifndef WebCore_FWD_JSCJSValue_h
#define WebCore_FWD_JSCJSValue_h
#include <JavaScriptCore/JSCJSValue.h>
#endif
