#ifndef WebCore_FWD_ExceptionHelpers_h
#define WebCore_FWD_ExceptionHelpers_h
#include <JavaScriptCore/ExceptionHelpers.h>
#endif
