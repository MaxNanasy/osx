/*
    This file is generated just to tell build scripts that JSTestImplements.h and
    JSTestImplements.cpp are created for TestImplements.idl, and thus
    prevent the build scripts from trying to generate JSTestImplements.h and
    JSTestImplements.cpp at every build. This file must not be tried to compile.
*/
