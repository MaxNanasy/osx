#ifndef WebCore_FWD_SlotVisitorInlines_h
#define WebCore_FWD_SlotVisitorInlines_h
#include <JavaScriptCore/SlotVisitorInlines.h>
#endif
