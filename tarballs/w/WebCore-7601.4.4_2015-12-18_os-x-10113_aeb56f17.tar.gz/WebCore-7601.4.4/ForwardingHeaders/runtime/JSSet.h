#ifndef WebCore_FWD_JSSet_h
#define WebCore_FWD_JSSet_h
#include <JavaScriptCore/JSSet.h>
#endif
