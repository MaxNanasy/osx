#ifndef WebCore_FWD_JSSetIterator_h
#define WebCore_FWD_JSSetIterator_h
#include <JavaScriptCore/JSSetIterator.h>
#endif
