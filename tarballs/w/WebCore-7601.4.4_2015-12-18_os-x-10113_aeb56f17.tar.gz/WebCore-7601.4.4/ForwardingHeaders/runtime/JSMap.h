#ifndef WebCore_FWD_JSMap_h
#define WebCore_FWD_JSMap_h
#include <JavaScriptCore/JSMap.h>
#endif
