#ifndef WebCore_FWD_Exception_h
#define WebCore_FWD_Exception_h
#include <JavaScriptCore/Exception.h>
#endif
