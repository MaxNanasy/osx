#ifndef WebCore_FWD_InspectorDebuggerAgent_h
#define WebCore_FWD_InspectorDebuggerAgent_h
#include <JavaScriptCore/InspectorDebuggerAgent.h>
#endif
