#ifndef WebCore_FWD_ScriptFunctionCall_h
#define WebCore_FWD_ScriptFunctionCall_h
#include <JavaScriptCore/ScriptFunctionCall.h>
#endif
