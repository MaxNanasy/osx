// This file is now intentionally empty. Delete it after removing it from all the build systems and project files.
