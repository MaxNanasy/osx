#ifndef WebCore_FWD_ParserError_h
#define WebCore_FWD_ParserError_h
#include <JavaScriptCore/ParserError.h>
#endif
