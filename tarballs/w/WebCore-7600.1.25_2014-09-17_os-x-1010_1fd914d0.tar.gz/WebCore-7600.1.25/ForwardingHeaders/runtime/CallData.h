#ifndef WebCore_FWD_CallData_h
#define WebCore_FWD_CallData_h
#include <JavaScriptCore/CallData.h>
#endif
