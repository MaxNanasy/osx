#ifndef WebCore_FWD_DateInstance_h
#define WebCore_FWD_DateInstance_h
#include <JavaScriptCore/DateInstance.h>
#endif
