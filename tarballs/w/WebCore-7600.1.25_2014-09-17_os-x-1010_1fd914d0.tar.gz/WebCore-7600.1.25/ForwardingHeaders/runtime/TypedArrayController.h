#ifndef WebCore_FWD_TypedArrayController_h
#define WebCore_FWD_TypedArrayController_h
#include <JavaScriptCore/TypedArrayController.h>
#endif
