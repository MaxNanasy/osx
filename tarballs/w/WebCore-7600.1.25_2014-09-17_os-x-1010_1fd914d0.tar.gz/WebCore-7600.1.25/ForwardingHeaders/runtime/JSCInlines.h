#ifndef WebCore_FWD_JSCInlines_h
#define WebCore_FWD_JSCInlines_h
#include <JavaScriptCore/JSCInlines.h>
#endif
