#ifndef WebCore_FWD_ScriptObject_h
#define WebCore_FWD_ScriptObject_h
#include <JavaScriptCore/ScriptObject.h>
#endif
