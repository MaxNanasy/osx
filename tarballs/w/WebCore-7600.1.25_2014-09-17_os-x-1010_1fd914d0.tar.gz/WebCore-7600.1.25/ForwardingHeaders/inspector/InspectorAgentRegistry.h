#ifndef WebCore_FWD_InspectorAgentRegistry_h
#define WebCore_FWD_InspectorAgentRegistry_h
#include <JavaScriptCore/InspectorAgentRegistry.h>
#endif
