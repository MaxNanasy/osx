#ifndef WebCore_FWD_ScriptDebugListener_h
#define WebCore_FWD_ScriptDebugListener_h
#include <JavaScriptCore/ScriptDebugListener.h>
#endif
