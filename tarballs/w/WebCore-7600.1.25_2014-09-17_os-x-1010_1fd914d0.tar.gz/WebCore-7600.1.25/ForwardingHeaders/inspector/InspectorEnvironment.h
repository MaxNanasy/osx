#ifndef WebCore_FWD_InspectorEnvironment_h
#define WebCore_FWD_InspectorEnvironment_h
#include <JavaScriptCore/InspectorEnvironment.h>
#endif
