#ifndef WebCore_FWD_ProfilerDatabase_h
#define WebCore_FWD_ProfilerDatabase_h
#include <JavaScriptCore/ProfilerDatabase.h>
#endif

