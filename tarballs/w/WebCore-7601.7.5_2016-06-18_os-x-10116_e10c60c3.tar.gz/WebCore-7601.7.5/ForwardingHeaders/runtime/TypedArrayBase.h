#ifndef WebCore_FWD_TypedArrayBase_h
#define WebCore_FWD_TypedArrayBase_h
#include <JavaScriptCore/TypedArrayBase.h>
#endif
