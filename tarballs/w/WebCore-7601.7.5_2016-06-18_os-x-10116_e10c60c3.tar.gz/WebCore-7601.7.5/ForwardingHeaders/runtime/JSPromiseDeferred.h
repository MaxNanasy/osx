#ifndef WebCore_FWD_JSPromiseDeferred_h
#define WebCore_FWD_JSPromiseDeferred_h
#include <JavaScriptCore/JSPromiseDeferred.h>
#endif
