#ifndef WebCore_FWD_JSONObject_h
#define WebCore_FWD_JSONObject_h
#include <JavaScriptCore/JSONObject.h>
#endif
