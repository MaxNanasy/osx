#ifndef WebCore_FWD_ConsoleClient_h
#define WebCore_FWD_ConsoleClient_h
#include <JavaScriptCore/ConsoleClient.h>
#endif
