#ifndef WebCore_FWD_FunctionConstructor_h
#define WebCore_FWD_FunctionConstructor_h
#include <JavaScriptCore/FunctionConstructor.h>
#endif
