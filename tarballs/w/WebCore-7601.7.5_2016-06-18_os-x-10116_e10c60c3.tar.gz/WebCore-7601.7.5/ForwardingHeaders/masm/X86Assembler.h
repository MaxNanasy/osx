#ifndef WebCore_FWD_X86Assembler_h
#define WebCore_FWD_X86Assembler_h
#include <JavaScriptCore/X86Assembler.h>
#endif
