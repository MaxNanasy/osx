#ifndef WebCore_FWD_Strong_h
#define WebCore_FWD_Strong_h
#include <JavaScriptCore/Strong.h>
#endif
