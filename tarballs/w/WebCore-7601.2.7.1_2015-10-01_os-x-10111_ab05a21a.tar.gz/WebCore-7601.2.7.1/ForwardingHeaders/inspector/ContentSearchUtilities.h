#ifndef WebCore_FWD_ContentSearchUtilities_h
#define WebCore_FWD_ContentSearchUtilities_h
#include <JavaScriptCore/ContentSearchUtilities.h>
#endif
