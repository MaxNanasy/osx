#ifndef WebCore_FWD_InspectorValues_h
#define WebCore_FWD_InspectorValues_h
#include <JavaScriptCore/InspectorValues.h>
#endif
