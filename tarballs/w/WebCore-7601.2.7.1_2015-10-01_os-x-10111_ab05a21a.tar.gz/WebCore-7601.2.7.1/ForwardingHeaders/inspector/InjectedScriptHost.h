#ifndef WebCore_FWD_InjectedScriptHost_h
#define WebCore_FWD_InjectedScriptHost_h
#include <JavaScriptCore/InjectedScriptHost.h>
#endif
