#ifndef WebCore_FWD_IdentifiersFactory_h
#define WebCore_FWD_IdentifiersFactory_h
#include <JavaScriptCore/IdentifiersFactory.h>
#endif
