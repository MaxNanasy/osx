#ifndef WebCore_FWD_ScriptCallStackFactory_h
#define WebCore_FWD_ScriptCallStackFactory_h
#include <JavaScriptCore/ScriptCallStackFactory.h>
#endif
