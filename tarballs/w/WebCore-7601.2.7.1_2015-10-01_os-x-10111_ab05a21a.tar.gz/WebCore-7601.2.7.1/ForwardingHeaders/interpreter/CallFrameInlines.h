#ifndef WebCore_FWD_CallFrameInlines_h
#define WebCore_FWD_CallFrameInlines_h
#include <JavaScriptCore/CallFrameInlines.h>
#endif
