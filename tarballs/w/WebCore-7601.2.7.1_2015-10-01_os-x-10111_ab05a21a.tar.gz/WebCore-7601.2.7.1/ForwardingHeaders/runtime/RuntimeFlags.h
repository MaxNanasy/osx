#ifndef WebCore_FWD_RuntimeFlags_h
#define WebCore_FWD_RuntimeFlags_h
#include <JavaScriptCore/RuntimeFlags.h>
#endif
