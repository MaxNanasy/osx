#ifndef WebCore_FWD_Completion_h
#define WebCore_FWD_Completion_h
#include <JavaScriptCore/Completion.h>
#endif
