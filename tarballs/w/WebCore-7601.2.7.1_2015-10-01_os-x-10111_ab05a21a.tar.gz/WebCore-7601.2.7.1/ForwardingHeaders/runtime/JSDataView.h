#ifndef WebCore_FWD_JSDataView_h
#define WebCore_FWD_JSDataView_h
#include <JavaScriptCore/JSDataView.h>
#endif
