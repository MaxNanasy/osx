#ifndef WebCore_FWD_Int16Array_h
#define WebCore_FWD_Int16Array_h
#include <JavaScriptCore/Int16Array.h>
#endif
