#ifndef WebCore_FWD_ErrorPrototype_h
#define WebCore_FWD_ErrorPrototype_h
#include <JavaScriptCore/ErrorPrototype.h>
#endif
