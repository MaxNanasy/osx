#ifndef WebCore_FWD_ArrayBufferView_h
#define WebCore_FWD_ArrayBufferView_h
#include <JavaScriptCore/ArrayBufferView.h>
#endif
