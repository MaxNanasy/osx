#ifndef TR_ERROR_H
#define TR_ERROR_H

extern void trError( void );

#endif

