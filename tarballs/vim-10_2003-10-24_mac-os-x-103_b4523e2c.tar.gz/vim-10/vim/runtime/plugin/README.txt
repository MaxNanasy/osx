The plugin directory is for standard Vim plugin scripts.

All files here ending in .vim will be sourced by Vim when it starts up.

Standard plugins:
explorer.vim	file browser
gzip.vim	edit compressed files
netrw.vim	edit files over a network
rrhelper.vim	used for --remote-wait editing
