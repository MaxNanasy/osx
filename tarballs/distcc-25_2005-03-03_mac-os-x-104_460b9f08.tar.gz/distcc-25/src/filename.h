const char * dcc_preproc_exten(const char *e);
