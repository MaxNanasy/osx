int dcc_cpp_maybe(char **argv, char *input_fname, char **cpp_fname,
		  pid_t *cpp_pid);
