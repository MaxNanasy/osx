#ifndef _TERMIOS_H
#define _TERMIOS_H

#include "win32_io.h"
/* Dummy for Winnt */

#endif
