/*
 * Copyright (c) 1999 Apple Computer, Inc. All rights reserved.
 *
 * @APPLE_LICENSE_HEADER_START@
 * 
 * "Portions Copyright (c) 1999 Apple Computer, Inc.  All Rights
 * Reserved.  This file contains Original Code and/or Modifications of
 * Original Code as defined in and that are subject to the Apple Public
 * Source License Version 1.0 (the 'License').  You may not use this file
 * except in compliance with the License.  Please obtain a copy of the
 * License at http://www.apple.com/publicsource and read it before using
 * this file.
 * 
 * The Original Code and all software distributed under the License are
 * distributed on an 'AS IS' basis, WITHOUT WARRANTY OF ANY KIND, EITHER
 * EXPRESS OR IMPLIED, AND APPLE HEREBY DISCLAIMS ALL SUCH WARRANTIES,
 * INCLUDING WITHOUT LIMITATION, ANY WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE OR NON-INFRINGEMENT.  Please see the
 * License for the specific language governing rights and limitations
 * under the License."
 * 
 * @APPLE_LICENSE_HEADER_END@
 */

#import "Root.h"
#import <NetInfo/syslock.h>

typedef enum
{
	LUCategoryUser,
	LUCategoryGroup,
	LUCategoryHost,
	LUCategoryNetwork,
	LUCategoryService,
	LUCategoryProtocol,
	LUCategoryRpc,
	LUCategoryMount,
	LUCategoryPrinter,
	LUCategoryBootparam,
	LUCategoryBootp,
	LUCategoryAlias,
	LUCategoryNetDomain,
	LUCategoryEthernet,
	LUCategoryNetgroup,
	LUCategoryInitgroups,
	LUCategoryHostServices
} LUCategory;

/* Number of categories above */
#define NCATEGORIES 17

/* Null Category (used for non-lookup dictionaries, e.g. statistics) */
#define LUCategoryNull ((LUCategory)-1)

/* shared CacheAgent */
extern id cacheAgent;

/* Configuration Manager (Config class) */
extern id configManager;

/* statistics LUDictionary */
extern id statistics;

/* RPC lock */
extern syslock *rpcLock;

/* statistics directory lock */
extern syslock *statsLock;

extern BOOL shutting_down;

#define DefaultName "lookupd"
