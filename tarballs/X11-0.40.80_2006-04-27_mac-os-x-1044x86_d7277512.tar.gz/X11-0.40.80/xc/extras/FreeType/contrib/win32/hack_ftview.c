/*********************************************************/
/* Test program driver for freetype  on Win32 Platform   */
/* CopyRight(left) G. Ramat 1998 (gcramat@radiostudio.it)*/
/*                                                       */
/*********************************************************/

#define exit(code) force_exit(code)
#define main(A,B)  ftview(A,B)
#include <ftview.c>
