0 4	* * *	root	efence_maintenance
