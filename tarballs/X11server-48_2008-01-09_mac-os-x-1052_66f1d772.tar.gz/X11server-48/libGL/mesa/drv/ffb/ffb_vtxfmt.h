/* $XFree86: xc/lib/GL/mesa/src/drv/ffb/ffb_vtxfmt.h,v 1.1 2002/02/22 21:32:59 dawes Exp $ */

#ifndef _FFB_VTXFMT_H
#define _FFB_VTXFMT_H

extern void ffbInitTnlModule(GLcontext *);

#endif /* !(_FFB_VTXFMT_H) */
