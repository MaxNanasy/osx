/* $XFree86: xc/lib/GL/mesa/src/drv/ffb/ffb_bitmap.h,v 1.1 2002/02/22 21:32:58 dawes Exp $ */

#ifndef _FFB_BITMAP_H
#define _FFB_BITMAP_H

extern void ffbDDInitBitmapFuncs(GLcontext *);

#endif /* !(_FFB_BITMAP_H) */
