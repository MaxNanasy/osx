/* $XFree86: xc/lib/GL/mesa/src/drv/ffb/ffb_clear.h,v 1.2 2002/02/22 21:32:58 dawes Exp $ */

#ifndef _FFB_CLEAR_H
#define _FFB_CLEAR_H

extern void ffbDDClear(GLcontext *ctx, GLbitfield mask, GLboolean all,
		       GLint cx, GLint cy, GLint cwidth, GLint cheight);

#endif /* !(_FFB_CLEAR_H) */
