//
//  main.m
//  RSSPhotoViewer
//
//  Created by Laurent Sansonetti on 2/6/07.
//  Copyright (c) 2007 Apple Computer. All rights reserved.
//

#import <RubyCocoa/RBRuntime.h>

int main(int argc, const char *argv[])
{
    return RBApplicationMain("rb_main.rb", argc, argv);
}
