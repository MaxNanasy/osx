//
//  main.m
//  HybridLangApp
//
//  Created by FUJIMOTO Hisakuni on Tue Dec 17 2002.
//  Copyright (c) 2002 __MyCompanyName__. All rights reserved.
//

#import <RubyCocoa/RBRuntime.h>

int main(int argc, const char *argv[])
{
    return RBApplicationMain("rb_main.rb", argc, argv);
}
