/* Copyright (c) 2013 Apple Inc. All rights reserved. */

#ifndef __APPLEKEYSTORE_EVENTS_H
#define __APPLEKEYSTORE_EVENTS_H

#define kAppleKeyStoreLockStatusNotificationID "com.apple.keystore.lockstatus"
#define kAppleKeyStoreFirstUnlockNotificationID "com.apple.keystore.firstunlock"

#endif // __APPLEKEYSTORE_EVENTS_H
