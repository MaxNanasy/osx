This directory is for symlinks to headers which will appear in the SDK under Security/, e.g.:

#include <Security/SecBase.h>
#include <Security/SecInternal.h>

Do not put anything but symlinks in this directory.
