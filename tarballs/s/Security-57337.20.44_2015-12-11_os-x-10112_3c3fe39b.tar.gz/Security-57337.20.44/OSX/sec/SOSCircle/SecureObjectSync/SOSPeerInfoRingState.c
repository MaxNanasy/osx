//
//  SOSPeerInfoRingState.c
//  sec
//
//  Created by Richard Murphy on 3/6/15.
//
//

#include "SOSPeerInfoRingState.h"

SOSRingStatus SOSPeerInfoGetRingState(SOSPeerInfoRef pi, CFStringRef ringname, CFErrorRef *error) {
    return kSOSRingError;
}
