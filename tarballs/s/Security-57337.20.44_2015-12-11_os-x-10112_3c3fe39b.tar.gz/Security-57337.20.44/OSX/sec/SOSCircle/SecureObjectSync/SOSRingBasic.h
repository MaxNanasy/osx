//
//  SOSRingBasic.h
//  sec
//
//  Created by Richard Murphy on 3/3/15.
//
//

#ifndef _sec_SOSRingBasic_
#define _sec_SOSRingBasic_

#include "SOSRingTypes.h"

extern ringFuncStruct basic;

#endif /* defined(_sec_SOSRingBasic_) */
