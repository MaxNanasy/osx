/* Don't preent multiple inclusions of this file */
#include <regressions/test/testmore.h>

ONE_TEST(authd_01_authorizationdb)
ONE_TEST(authd_02_basicauthorization)
