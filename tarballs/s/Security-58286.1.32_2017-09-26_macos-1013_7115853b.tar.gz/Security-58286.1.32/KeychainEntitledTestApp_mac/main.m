//
//  main.m
//  KeychainEntitledTestApp_mac
//
//  Copyright (c) 2017 Apple Inc. All rights reserved.
//
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
