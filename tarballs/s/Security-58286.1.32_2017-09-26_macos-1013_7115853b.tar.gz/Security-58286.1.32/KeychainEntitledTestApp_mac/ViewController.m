//
//  ViewController.m
//  KeychainEntitledTestApp_mac
//
//  Copyright (c) 2017 Apple Inc. All rights reserved.
//
//

#import "ViewController.h"

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    // Do any additional setup after loading the view.
}


- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}


@end
