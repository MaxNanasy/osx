//
//  AppDelegate.h
//  KeychainEntitledTestApp_mac
//
//  Copyright (c) 2017 Apple Inc. All rights reserved.
//
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

