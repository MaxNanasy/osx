/* To add a test:
 1) add it here
 2) Add it as command line argument for SecurityTest.app in the Release and Debug schemes
 */
#include <test/testmore.h>

ONE_TEST(sc_20_keynames)
ONE_TEST(sc_25_soskeygen)
ONE_TEST(sc_30_peerinfo)
ONE_TEST(sc_31_peerinfo)
ONE_TEST(sc_40_circle)
ONE_TEST(sc_42_circlegencount)
ONE_TEST(sc_45_digestvector)

ONE_TEST(sc_130_resignationticket)
ONE_TEST(sc_150_Ring)
ONE_TEST(sc_140_hsa2)

ONE_TEST(sc_150_backupkeyderivation)
ONE_TEST(sc_153_backupslicekeybag)
