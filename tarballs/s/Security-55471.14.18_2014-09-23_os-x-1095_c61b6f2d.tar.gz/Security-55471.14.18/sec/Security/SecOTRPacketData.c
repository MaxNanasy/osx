//
//  SecOTRPacketData.c
//  libsecurity_libSecOTR
//
//  Created by Mitch Adler on 2/26/11.
//  Copyright 2011 Apple Inc. All rights reserved.
//

#include "SecOTRPacketData.h"

