//
//  DeviceViewController.h
//  Security
//
//  Created by john on 11/18/12.
//
//

#import <UIKit/UIKit.h>

@interface DeviceViewController : UIViewController

@end
