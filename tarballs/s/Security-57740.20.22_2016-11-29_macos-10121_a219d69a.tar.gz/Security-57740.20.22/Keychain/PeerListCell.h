//
//  PeerListCell.h
//  Security
//
//  Created by Mitch Adler on 12/4/12.
//
//

#import <UIKit/UIKit.h>

@interface PeerListCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *peerName;
@property (weak, nonatomic) IBOutlet UILabel *peerCircle;

@end
