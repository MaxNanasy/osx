//
//  CircleStatusView.h
//  Security
//
//  Created by John Hurley on 12/5/12.
//
//

#import <UIKit/UIKit.h>

@interface CircleStatusView : UIView
{
}
@property (weak, nonatomic) UIColor *color;

@end

@interface ItemStatusView : UIView
{
}
@property (weak, nonatomic) UIColor *color;

@end


