This project is a copy of the normal Foundation command-line tool, and the differences are summarized below.

It uses the standard Debug and Release configurations. Currently, command-line tools aren't supported in the Simulator.

Thanks!
