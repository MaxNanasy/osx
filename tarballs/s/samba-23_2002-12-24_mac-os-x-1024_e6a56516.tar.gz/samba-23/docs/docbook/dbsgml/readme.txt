README for DocBook V4.1

This is DocBook V4.1, released 19 June 2000.

See 40chg.txt for information about what has changed since DocBook 3.1.

For more information about DocBook, please see

  http://www.oasis-open.org/docbook/

Please send all questions, comments, concerns, and bug reports to the
DocBook mailing list: docbook@lists.oasis-open.org
