/******************************************************************************
** 
**  $Id: p11x_bio.c,v 1.2 2003/02/13 20:06:40 ghoo Exp $
**
**  Package: PKCS-11
**  Author : Chris Osgood <oznet@mac.com>
**  License: Copyright (C) 2002 Chris Osgood
**  Purpose: Biometric support functions to be used instead of a normal PIN.
** 
******************************************************************************/

