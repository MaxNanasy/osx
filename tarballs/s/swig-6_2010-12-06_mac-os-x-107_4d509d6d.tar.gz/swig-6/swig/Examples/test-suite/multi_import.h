class XXX
{
	public:
		int testx() { return 0;}
};

class YYY : public XXX
{
	public:
		int testy() { return 1;}
};

class ZZZ : public XXX
{
	public:
		int testz() { return 2;}
};
