int IntegerMember;
double DoubleMember;
