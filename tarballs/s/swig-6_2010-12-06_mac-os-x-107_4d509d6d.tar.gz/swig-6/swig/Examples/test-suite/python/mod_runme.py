import mod_a
import mod_b

c = mod_b.C()
d = mod_b.D()
d.DoSomething(c)
