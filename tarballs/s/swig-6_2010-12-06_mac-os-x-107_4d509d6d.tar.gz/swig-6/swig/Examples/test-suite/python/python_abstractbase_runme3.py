from python_abstractbase import *
from collections import *
assert issubclass(Mapii, MutableMapping)
assert issubclass(Multimapii, MutableMapping)
assert issubclass(IntSet, MutableSet)
assert issubclass(IntMultiset, MutableSet)
assert issubclass(IntVector, MutableSequence)
assert issubclass(IntList, MutableSequence)
