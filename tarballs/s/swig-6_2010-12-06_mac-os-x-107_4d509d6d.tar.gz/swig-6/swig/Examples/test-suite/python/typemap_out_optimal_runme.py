from typemap_out_optimal import *

cvar.XX_debug = False
x = XX.create()

