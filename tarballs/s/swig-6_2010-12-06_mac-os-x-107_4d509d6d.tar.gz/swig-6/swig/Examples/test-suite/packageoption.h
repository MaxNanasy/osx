struct Base {
  virtual int vmethod() { return 1; }
  int basemethod() { return 1; }
  virtual ~Base() {}
};

