//
//  SWCViewController.h
//  SharedWebCredentialViewService
//
//  Copyright (c) 2014 Apple Inc. All Rights Reserved.
//

#import <UIKit/UIKit.h>
#import <SpringBoardUIServices/SBSUIRemoteAlertItemContentViewController.h>

@interface SWCViewController : SBSUIRemoteAlertItemContentViewController <UITableViewDelegate, UITableViewDataSource>

@end
