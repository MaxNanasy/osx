//
//  main.m
//  SharedWebCredentialViewService
//
//  Copyright (c) 2014 Apple Inc. All Rights Reserved.
//

#import <UIKit/UIKit.h>

#import "SWCAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SWCAppDelegate class]));
    }
}
