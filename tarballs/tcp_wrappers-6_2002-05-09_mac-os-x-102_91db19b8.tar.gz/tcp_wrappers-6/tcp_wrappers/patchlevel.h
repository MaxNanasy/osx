#ifndef lint
static char patchlevel[] = "@(#) patchlevel 7.6 97/03/21 19:27:23";
#endif
