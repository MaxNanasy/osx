README_fr - CUPS v1.1.19 - 04/08/2003
-------------------------------------

Vous cherchez des instructions d'installation ? Lisez le fichier
INSTALL.txt (anglais) et/ou reportez vous au "Manuel de
l'administrateur" (en fran�ais) situ� dans le sous-r�pertoire
"doc/fr"

Vous trouverez deux autres manuels en fran�ais dans ce
sous-r�pertoire :

	- Aper�u de CUPS
	- Manuel de l'utilisateur

Une fois CUPS install�, si vous configurez votre navigateur
"web" pour que  la langue de base soit le fran�ais, vous
disposerez �galement d'une interface "web" en fran�ais pour
l'administration et d'utilistation de CUPS.

