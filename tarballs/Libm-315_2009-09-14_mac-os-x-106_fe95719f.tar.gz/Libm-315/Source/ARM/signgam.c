/*
 *	signgam.c
 *
 *		by Ian Ollmann
 *
 *	Copyright (c) 2007 Apple Inc. All Rights Reserved.
 */
 
#include <math.h>

int signgam;		//purposefully not initialized to avoid having to create a new page to hold this and initialize at app launch.
