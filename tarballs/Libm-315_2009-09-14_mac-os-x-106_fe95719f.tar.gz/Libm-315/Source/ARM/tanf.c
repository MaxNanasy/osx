#define	Name	tanf

#include "tanf.h"
