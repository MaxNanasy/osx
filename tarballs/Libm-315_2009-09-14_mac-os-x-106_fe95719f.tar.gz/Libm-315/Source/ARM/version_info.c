/*
 *  version_info.c
 *  Libm
 *
 *  Created by Ian Ollmann on 6/27/07.
 *  Copyright 2007 Apple Inc. All rights reserved.
 *
 */

extern const char Libm_version[];
const char __Libm_version[] = "@(#) " LIBM_VERSION_STRING " " __DATE__ " " __TIME__;
