#define RROP GXcopy
#include "../cfb/cfbzerarc.c"
