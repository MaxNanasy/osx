#define GLYPHROP
#include "../cfb/cfbglblt8.c"
