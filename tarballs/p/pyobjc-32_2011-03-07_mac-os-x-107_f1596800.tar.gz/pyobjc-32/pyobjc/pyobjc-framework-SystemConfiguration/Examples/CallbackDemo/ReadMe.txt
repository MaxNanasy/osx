The scripts in this directory are command-line scripts that usage some of the
callback API's in the SystemConfiguration framework.

These scripts are mostly here to check if those callbacks work as expected (
instead of using unittests) and are not generally usefull.
