
from PyObjCTools.TestSupport import *
from Quartz.CoreGraphics import *

class TestCGPDFObject (TestCase):

    @expectedFailure
    def testIncomplete(self):
        self.fail("Add header tests for <CoreGraphics/CGPDFObject.h>")

if __name__ == "__main__":
    main()
