from PyObjCTools import AppHelper
import TransitionSelectorView

import objc
objc.setVerbose(True)
AppHelper.runEventLoop()
