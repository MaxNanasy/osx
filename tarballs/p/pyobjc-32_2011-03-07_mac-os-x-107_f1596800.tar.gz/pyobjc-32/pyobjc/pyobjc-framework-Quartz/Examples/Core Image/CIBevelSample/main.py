from PyObjCTools import AppHelper

import CIBevelView
import SampleCIView

import objc; objc.setVerbose(True)

AppHelper.runEventLoop()
