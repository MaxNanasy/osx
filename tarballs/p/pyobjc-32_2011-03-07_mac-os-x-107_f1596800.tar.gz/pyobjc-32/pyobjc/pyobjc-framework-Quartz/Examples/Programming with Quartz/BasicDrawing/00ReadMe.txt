Issues with this example:

- Functionality using QuickTime doesn't work at all, the required functionality
  is not wrapped in Python.

- Colorspace handling in Utilities.py isn't the same as in the C version of
  this code.
