SillyBallsSaver

Example showing screen saver in Python

Based on "Silly Balls.saver" by Eric Peyton <epeyton@epicware.com>
    

See:    http://www.epicware.com/macosxsavers.html
        http://developer.apple.com/documentation/UserExperience/Reference/ScreenSaver/ObjC_classic/Classes/ScreenSaverView.html
        http://www.cocoadev.com/index.pl?ScreenSaver

The source of this application demonstrates
- Writing a ScreenSaver in PyObjC
- Building plug-in bundles in PyObjC

Jason Toffaletti <catalyst@mac.com>
