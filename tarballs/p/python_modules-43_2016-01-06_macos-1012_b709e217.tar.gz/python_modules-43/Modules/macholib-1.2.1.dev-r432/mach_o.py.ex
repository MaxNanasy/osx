g/\<p_long\>/s//p_int/g
g/\<p_ulong\>/s//p_uint/g
/^LC_REGISTRY = {/-1i
# Used to represent unknown load commands
class unknown_command(Structure):
    _fields_ = (
    )

.
wq
