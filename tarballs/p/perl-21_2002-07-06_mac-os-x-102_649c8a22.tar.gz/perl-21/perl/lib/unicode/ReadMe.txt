June 23, 1999

This directory contains the initial release for Unicode 3.0.

This release consists of corrections and additions to the
Unicode Character Database, to match the publication of
The Unicode Standard, Version 3.0.

Detailed documentation of the files constituting the
Unicode Character Database (contributory data files for
the standard itself) can now be found in
UnicodeCharacterDatabase.html.

--------------------------------------------------------------------------
NOTE NOTE NOTE NOTE NOTE NOTE NOTE NOTE NOTE NOTE NOTE NOTE NOTE NOTE NOTE 

The files have been copied from

	ftp://ftp.unicode.org/Public/3.0-Update/

and most of them have been renamed to better fit 8.3 filename limitations.

long name at unicode.org		short name		latest '#'
------------------------		----------		----------
ArabicShaping-#.txt			ArabShap.txt		2
Blocks-#.txt				Blocks.txt		3
CompositionExclusions-#.txt		CompExcl.txt		1
EastAsianWidth-#.txt			EAWidth.txt		3
Index-#.txt				Index.txt		3.0.0
Jamo-#.txt				Jamo.txt		2
LineBreak-#.txt				LineBrk.txt		5
NamesList-#.txt				Names.txt		3.0.0
NamesList-#.html			NamesList.html		1
PropList-#.txt				Props.txt		3.0.0
SpecialCasing-#.txt			SpecCase.txt		2
UnicodeData-#.txt			Unicode.300		3.0.0
UnicodeData-#.html			Unicode3.html		3.0.0
UnicodeCharacterDatabase-#.html		UCD300.html		3.0.0

The *.pl files are generated from these files by the 'mktables.PL' script.

While the files have been renamed the links in the html files haven't.

-- 
jhi@iki.fi
