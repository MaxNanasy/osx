PyInterpreter

PyInterpreter is a full featured Python interpreter in a NSTextView.

See:    http://pyobjc.sourceforge.net/
        http://pythonmac.org/wiki/PyInterpreter

Source for both the pyobjc module and PyInterpreter are
available via the pyobjc sourceforge CVS repository.

The source of this application demonstrates
- Advanced usage of NSTextView
- Manual event dispatching
- Text completion (Only in OS X 10.3)

Bob Ippolito
bob@redivi.com
