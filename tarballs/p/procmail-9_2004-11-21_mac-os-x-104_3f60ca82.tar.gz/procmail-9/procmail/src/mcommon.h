/*$Id: mcommon.h,v 1.1.1.2 2001/07/20 19:38:18 bbraun Exp $*/

void
 qsignal P((const int sig,void(*action)(void)));
