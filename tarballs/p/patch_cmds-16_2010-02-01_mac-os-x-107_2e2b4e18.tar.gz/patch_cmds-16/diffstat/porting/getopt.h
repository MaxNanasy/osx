extern char *optarg;
extern int optind, opterr;

int getopt (int argc, char *const*argv, const char *options);
