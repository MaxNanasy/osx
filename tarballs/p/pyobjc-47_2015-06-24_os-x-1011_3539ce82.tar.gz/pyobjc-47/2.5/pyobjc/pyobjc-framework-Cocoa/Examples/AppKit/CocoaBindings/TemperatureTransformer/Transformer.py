from PyObjCTools import AppHelper
# import classes required to start application
import TransformerAppDelegate

if __name__ == '__main__':
    AppHelper.runEventLoop()
