from Cocoa import *

class CurrencyConvBindingDocument (NSDocument):
    def windowNibName(self):
        return "CurrencyConvBindingDocument"
