#
#  ControlledPreferences
#
#

from PyObjCTools import AppHelper

# import classes required to start application
import PreferencesPanelController
import FontNameToDisplayNameTransformer
import FontSampleDisplayView

# start the event loop
AppHelper.runEventLoop()
