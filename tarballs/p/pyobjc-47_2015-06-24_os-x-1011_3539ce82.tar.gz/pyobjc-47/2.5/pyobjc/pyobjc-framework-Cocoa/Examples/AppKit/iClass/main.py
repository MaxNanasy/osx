"""
"""
import time
from AppKit import NSApplicationMain
from PyObjCTools import AppHelper
from Foundation import NSBundle
import sys
import os

import datasource

AppHelper.runEventLoop()
