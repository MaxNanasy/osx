g/\(,[[:space:]]*\)\?['"]-isysroot['"],[[:space:]]*['"]\/['"]/s///
wq
