"""
Header file scanner for generating MetaData.xml files.

This package is unstable, the interface may change at any moment.
"""
