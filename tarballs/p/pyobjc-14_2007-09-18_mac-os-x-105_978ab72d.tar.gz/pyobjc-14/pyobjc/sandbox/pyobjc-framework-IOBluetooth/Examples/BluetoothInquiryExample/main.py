from PyObjCTools import AppHelper

import BluetoothExplorerWindow

AppHelper.runEventLoop()
