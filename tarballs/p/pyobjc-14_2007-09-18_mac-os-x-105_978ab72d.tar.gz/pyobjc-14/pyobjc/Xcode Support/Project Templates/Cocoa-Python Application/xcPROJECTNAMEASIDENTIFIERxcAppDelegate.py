#
#  xcPROJECTNAMEASIDENTIFIERxcAppDelegate.py
#  xcPROJECTNAMExc
#
#  Created by xcFULLUSERNAMExc on xcDATExc.
#  Copyright xcORGANIZATIONNAMExc xcYEARxc. All rights reserved.
#

from Foundation import *
from AppKit import *

class xcPROJECTNAMEASIDENTIFIERxcAppDelegate(NSObject):
    def applicationDidFinishLaunching_(self, sender):
        NSLog("Application did finish launching.")
