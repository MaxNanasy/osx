#
#  «FILENAME»
#  «PROJECTNAME»
#
#  Created by «FULLUSERNAME» on «DATE».
#  Copyright (c) «YEAR» «ORGANIZATIONNAME». All rights reserved.
#

from objc import YES, NO, IBAction, IBOutlet
from Foundation import *
from AppKit import *

class «FILEBASENAMEASIDENTIFIER»(NSWindowController):
    pass
