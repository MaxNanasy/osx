#
#  «FILENAME»
#  «PROJECTNAME»
#
#  Created by «FULLUSERNAME» on «DATE».
#  Copyright (c) «YEAR» «ORGANIZATIONNAME». All rights reserved.
#

from Foundation import *

class «FILEBASENAMEASIDENTIFIER»(NSObject):
    pass
