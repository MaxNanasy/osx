#
#  «FILENAME»
#  «PROJECTNAME»
#
#  Created by «FULLUSERNAME» on «DATE».
#  Copyright (c) «YEAR» «ORGANIZATIONNAME». All rights reserved.
#

from objc import YES, NO, IBAction, IBOutlet
from Foundation import *
from AppKit import *

class «FILEBASENAMEASIDENTIFIER»(NSView):
    def initWithFrame_(self, frame):
        self = super(«FILEBASENAMEASIDENTIFIER», self).initWithFrame_(frame)
        if self:
            # initialization code here
            pass
        return self

    def drawRect_(self, rect):
        # drawing code here

