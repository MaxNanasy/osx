//	Prefix header for CodeWarrior Mach-O Kerberos.app build

// debug new seems to give false warnings on std::string so we'll disable
// it so we can keep using rest of debugging classes
#define PP_DEBUGNEW_SUPPORT			0

#include "KM_Headers.MO"
