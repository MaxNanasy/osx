/* CodeWarrior Pro 7 neglects to define this for us under X, causing
   TARGET_API_MAC_CARBON not to be defined. */

#define environ_os_mac 1
#define Environ_OS_Win32 0
#define Environ_OS_Unix 0
#define Environ_OS_Mac 0