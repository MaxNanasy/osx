/*
 * module to include the modules
 */

config_require(if-mib/data_access/interface);
config_require(ip-mib/data_access/ipaddress);
config_require(ip-mib/ipAddressTable/ipAddressTable);
config_require(ip-mib/ipAddressTable/ipAddressTable_interface);
config_require(ip-mib/ipAddressTable/ipAddressTable_data_access);
