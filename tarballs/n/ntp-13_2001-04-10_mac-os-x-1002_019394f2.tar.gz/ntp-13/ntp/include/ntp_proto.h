#ifndef __ntp_proto_h
#define __ntp_proto_h

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#endif /* __ntp_proto_h */
