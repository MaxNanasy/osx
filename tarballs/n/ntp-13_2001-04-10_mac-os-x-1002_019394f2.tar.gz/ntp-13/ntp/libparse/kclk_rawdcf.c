/*
 * /src/NTP/ntp-4/libparse/kclk_rawdcf.c,v 4.1 1998/06/13 12:07:55 kardel RELEASE_19990228_A
 *
 * $Created: Sat Jun 13 10:03:35 1998 $
 *
 * Copyright (C) 1998 by Frank Kardel
 */
#define PARSESTREAM
#include "clk_rawdcf.c"
/*
 * kclk_rawdcf.c,v
 * Revision 4.1  1998/06/13 12:07:55  kardel
 * standard format
 *
 */
