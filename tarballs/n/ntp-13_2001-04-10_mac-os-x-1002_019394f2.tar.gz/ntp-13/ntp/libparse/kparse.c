/*
 * /src/NTP/ntp-4/libparse/kparse.c,v 4.2 1998/07/11 10:05:29 kardel RELEASE_19990228_A
 *
 * $Created: Sat Jun 13 10:04:47 1998 $
 *
 * Copyright (C) 1998 by Frank Kardel
 */
#define PARSESTREAM
#include "parse.c"
/*
 * kparse.c,v
 * Revision 4.2  1998/07/11 10:05:29  kardel
 * Release 4.0.73d reconcilation
 *
 * Revision 4.1  1998/06/13 12:08:12  kardel
 * standard format
 */
