/*
 * $Header: /cvs/Darwin/Services/ntp/ntp/libparse/kclk_varitext.c,v 1.1.1.1 1999/09/17 01:10:19 wsanchez Exp $
 *
 * $Created: Sat Jun 13 09:58:27 1998 $
 *
 * Copyright (C) 1998 by Frank Kardel
 */
#define PARSESTREAM
#include "clk_varitext.c"
/*
 * $Log: kclk_varitext.c,v $
 * Revision 1.1.1.1  1999/09/17 01:10:19  wsanchez
 * Import of ntp-4.0.95
 *
 * Revision 1.1.1.1  1999/08/09 18:31:15  wsanchez
 * Import of ntp 4.0.95
 *
 * Revision 1.1  1999/07/25 09:21:16  stenn
 * * configure.in: 4.0.94b
 *
 * * acconfig.h:
 * * configure.in:
 * * libparse/Makefile.am:
 * * libparse/parse_conf.c:
 * * libparse/clk_varitext.c:
 * * libparse/kclk_varitext.c:
 * * ntpd/refclock_parse.c: VARITEXT parse clock
 * * ntpdate/ntpdate.c: bugfix
 * From: Tony McConnell <tonym@datel-technology.co.uk>
 *
 * Revision 4.1  1998/06/13 12:09:27  kardel
 * hack to compile the source for kernel/user-land
 *
 */
