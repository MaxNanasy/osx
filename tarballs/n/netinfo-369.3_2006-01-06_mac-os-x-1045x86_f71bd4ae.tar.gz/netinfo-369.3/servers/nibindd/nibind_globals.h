/*
 * Globals used by the NetInfo registry.
 * Copyright (C) 1989 by NeXT, Inc.
 */

/*
 * Variables
 */
extern int debug;
extern int udp_sock;
