package # hide from PAUSE 
    CDBase;

use strict;
use base qw(DBIx::Class::Test::SQLite);

1;
