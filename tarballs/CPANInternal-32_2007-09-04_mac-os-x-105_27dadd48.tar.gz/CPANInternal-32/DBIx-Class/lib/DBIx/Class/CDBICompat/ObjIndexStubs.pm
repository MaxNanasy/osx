package # hide from PAUSE
    DBIx::Class::CDBICompat::ObjIndexStubs;

use strict;
use warnings;

sub remove_from_object_index { }

sub clear_object_index { }

1;
