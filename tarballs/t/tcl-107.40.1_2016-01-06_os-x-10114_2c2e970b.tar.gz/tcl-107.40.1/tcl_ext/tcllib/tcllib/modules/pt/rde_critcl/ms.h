/* pt::rde::critcl - critcl - layer 2 declarations
 * Support for param methods.
 */

#ifndef _MS_H
#define _MS_H 1

#include "tcl.h"

int paramms_objcmd (ClientData cd, Tcl_Interp* interp, int objc, Tcl_Obj* CONST* objv);

#endif /* _MS_H */

/*
 * Local Variables:
 * mode: c
 * c-basic-offset: 4
 * fill-column: 78
 * End:
 */
