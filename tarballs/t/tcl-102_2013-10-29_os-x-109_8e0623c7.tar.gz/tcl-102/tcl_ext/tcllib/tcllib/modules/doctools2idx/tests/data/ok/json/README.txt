This section holds json input which is non-canonical, i.e. in the
proper format, with the keys not alphabetically. This is acceptable as
input, and the importer makes it canonical for the higher layers.
