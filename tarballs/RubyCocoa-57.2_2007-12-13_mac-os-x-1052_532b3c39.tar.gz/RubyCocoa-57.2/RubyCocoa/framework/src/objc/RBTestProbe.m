/*
 * Copyright (c) 2006-2007, The RubyCocoa Project.
 * Copyright (c) 2001-2006, FUJIMOTO Hisakuni.
 * All Rights Reserved.
 *
 * RubyCocoa is free software, covered under either the Ruby's license or the
 * LGPL. See the COPYRIGHT file for more information.
 */

#import <Foundation/Foundation.h>
#import "ocdata_conv.h"

@interface RBCacheTestProbe : NSObject
@end

@implementation RBCacheTestProbe

+ (BOOL)findInOcidToRbobjCache:(id)ocid
{
  return ocid_to_rbobj_cache_only(ocid) != Qnil;
}

@end
