if nul = $:.index("-")
  $:[nul..-1] = ["."]
end
