require 'mkmf'
create_makefile('stringio')
