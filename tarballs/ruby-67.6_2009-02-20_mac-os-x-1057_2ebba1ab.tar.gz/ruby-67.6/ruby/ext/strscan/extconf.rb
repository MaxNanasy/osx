require 'mkmf'
create_makefile 'strscan'
