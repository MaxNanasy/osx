package org.jbossmx.cluster.watchdog.util.xml;

public interface XMLContext
{
}