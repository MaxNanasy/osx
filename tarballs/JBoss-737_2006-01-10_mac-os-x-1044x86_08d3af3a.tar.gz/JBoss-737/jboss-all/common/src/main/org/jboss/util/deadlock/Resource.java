package org.jboss.util.deadlock;

/**
 * Created by IntelliJ IDEA.
 * User: wburke
 * Date: Aug 21, 2003
 * Time: 2:11:52 PM
 * To change this template use Options | File Templates.
 */
public interface Resource
{
   Object getResourceHolder();
}
