/*
 *  AOAHALPlugin.c
 *  AppleOnboardAudio
 *
 *  Created by cerveau on Mon May 28 2001.
 *  Copyright (c) 2001 Apple Computer, Inc. All rights reserved.
 *
 */

#include "AOAHALPlugin.h"

                                
/*OSStatus AudioDriverPlugInOpen(AudioDriverPlugInHostInfo* inHostInfo){
   // fprintf(stderr, "HAL PLugin OPEN \n");
    return(0);
}

OSStatus AudioDriverPlugInClose(AudioDeviceID inDevice){
   // fprintf(stderr, "HAL PLugin Close \n");
    return(0);
}


OSStatus AudioDriverPlugInGetPropertyInfo(AudioDeviceID	inDevice,
                                            UInt32 inLine,
                                            Boolean isInput,
                                            AudioDevicePropertyID inPropertyID,
                                            UInt32*	outSize,
                                            Boolean*  outWritable);


OSStatus AudioDriverPlugInGetProperty(AudioDeviceID inDevice,
                                    UInt32					inLine,
								Boolean					isInput,
								AudioDevicePropertyID	inPropertyID,
								UInt32*					ioPropertyDataSize,
								void*					outPropertyData){
}                                            

OSStatus AudioDriverPlugInSetProperty(	AudioDeviceID			inDevice,
								const AudioTimeStamp*	inWhen,
								UInt32					inLine,
								Boolean					isInput,
								AudioDevicePropertyID	inPropertyID,
								UInt32					inPropertyDataSize,
								const void*				inPropertyData){
}                                */
