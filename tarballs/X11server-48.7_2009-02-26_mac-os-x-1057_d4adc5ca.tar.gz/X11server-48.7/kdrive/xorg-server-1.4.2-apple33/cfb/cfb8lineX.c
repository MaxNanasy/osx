#define RROP GXxor
#include "../cfb/cfb8line.c"
