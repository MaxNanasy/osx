#define MROP Mcopy
#include "../cfb/cfbblt.c"
