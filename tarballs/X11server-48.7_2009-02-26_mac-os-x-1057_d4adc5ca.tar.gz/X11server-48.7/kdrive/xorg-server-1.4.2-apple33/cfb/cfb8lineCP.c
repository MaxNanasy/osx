#define RROP GXcopy
#define PREVIOUS
#include "../cfb/cfb8line.c"
