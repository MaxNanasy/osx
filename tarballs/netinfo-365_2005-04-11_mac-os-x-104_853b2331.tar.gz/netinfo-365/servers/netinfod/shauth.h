/*
 *  shauth.h
 *
 *  Created by kaw on Wed Apr 16 2003.
 *  Copyright (c) 2003 Apple Computer. All rights reserved.
 *
 */

int DoSHAuth(char* userName, char* password, char* inGUID);
