/* This file is generated automatically by configure. */

CHARSET_INFO compiled_charsets[] = {

  /* this information is filled in by configure */
  {
      8,    /* number */
    "latin1",     /* name */
    ctype_latin1,
    to_lower_latin1,
    to_upper_latin1,
    sort_order_latin1,
    0,          /* strxfrm_multiply */
    NULL,       /* strcoll    */
    NULL,       /* strxfrm    */
    NULL,       /* strnncoll  */
    NULL,       /* strnxfrm   */
    NULL,       /* like_range */
    0,          /* mbmaxlen  */
    NULL,       /* ismbchar  */
    NULL,       /* ismbhead  */
    NULL        /* mbcharlen */
  },

  /* this information is filled in by configure */
  {
    0,          /* end-of-list marker */
    NullS,
    NULL,
    NULL,
    NULL,
    NULL,
    0,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    0,
    NULL,
    NULL,
    NULL
  }
};
