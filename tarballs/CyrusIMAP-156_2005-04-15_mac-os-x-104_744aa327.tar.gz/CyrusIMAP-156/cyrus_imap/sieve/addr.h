#ifndef BISON_Y_TAB_H
# define BISON_Y_TAB_H

# ifndef YYSTYPE
#  define YYSTYPE int
#  define YYSTYPE_IS_TRIVIAL 1
# endif
# define	ATOM	257
# define	QTEXT	258
# define	DTEXT	259


extern YYSTYPE addrlval;

#endif /* not BISON_Y_TAB_H */
