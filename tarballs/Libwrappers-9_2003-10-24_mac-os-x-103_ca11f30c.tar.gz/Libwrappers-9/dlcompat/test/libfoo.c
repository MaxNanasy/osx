#include <unistd.h>
#include <stdio.h>

int foo(int number)
{
printf("foo %s %s",__FILE__,__LINE__);
}
