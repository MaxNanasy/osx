/* Copyright (c) 1999-2000, International Business Machines Corporation and
   others. All Rights Reserved. */
/* Define to signed char if not in <sys/types.h> */
#undef int8_t

/* Define to unsigned char if not in <sys/types.h> */
#undef uint8_t 

/* Define to signed short if not in <sys/types.h> */
#undef int16_t 

/* Define to unsigned short if not in <sys/types.h> */
#undef uint16_t 

/* Define to signed long if not in <sys/types.h> */
#undef int32_t 

/* Define to unsigned long if not in <sys/types.h> */
#undef uint32_t 

/* Define to signed char if not in <sys/types.h> */
#undef bool_t 

/* Define if your system has <wchar.h> */
#undef HAVE_WCHAR_H

/* Define to the size of wchar_t */
#undef SIZEOF_WCHAR_T

