README_mac.txt for version 7.2 of Vim: Vi IMproved.

This file explains the installation of Vim on Macintosh systems.
See "README.txt" for general information about Vim.


Sorry, this text still needs to be written!

