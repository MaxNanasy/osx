/* pathdef.c */
/* This file is automatically created by Makefile
 * DO NOT EDIT!  Change Makefile only. */
#include "vim.h"
char_u *default_vim_dir = (char_u *)"/usr/share/vim";
char_u *default_vimruntime_dir = (char_u *)"";
char_u *all_cflags = (char_u *)"gcc -c -I. -D_FORTIFY_SOURCE=0 -Iproto -DHAVE_CONFIG_H     -arch armv7 -arch i386 -arch x86_64 -g -Os -pipe -mdynamic-no-pic        ";
char_u *all_lflags = (char_u *)"gcc   -arch armv7 -arch i386 -arch x86_64             -o vim       -lm  -lncurses        ";
char_u *compiled_user = (char_u *)"stripes";
char_u *compiled_sys = (char_u *)"il0204d-dhcp43.apple.com";
