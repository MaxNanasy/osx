int tcl_init __P((GS *));
