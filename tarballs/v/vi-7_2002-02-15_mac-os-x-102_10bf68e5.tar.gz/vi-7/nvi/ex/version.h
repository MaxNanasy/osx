#define	VI_VERSION \
	"Version 1.79 (10/23/96) The CSRG, University of California, Berkeley."
