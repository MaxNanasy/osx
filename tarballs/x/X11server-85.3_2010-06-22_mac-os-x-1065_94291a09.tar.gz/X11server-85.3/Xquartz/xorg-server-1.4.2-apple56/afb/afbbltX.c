#define MROP Mxor
#include "./afbblt.c"
