#define MROP 0
#include "./afbblt.c"
