#define RROP GXcopy
#include "../cfb/cfbply1rct.c"
