#define RROP GXset
#include "../cfb/cfbfillarc.c"
