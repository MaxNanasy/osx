#define RROP GXcopy
#define POLYSEGMENT
#define WIDTH_SHIFT
#include "../cfb/cfb8line.c"
