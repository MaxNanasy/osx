#define RROP GXset
#include "../cfb/cfbsolid.c"
