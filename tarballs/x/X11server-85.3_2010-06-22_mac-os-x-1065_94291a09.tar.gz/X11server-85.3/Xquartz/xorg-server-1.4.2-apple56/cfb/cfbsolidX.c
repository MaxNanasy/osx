#define RROP GXxor
#include "../cfb/cfbsolid.c"
