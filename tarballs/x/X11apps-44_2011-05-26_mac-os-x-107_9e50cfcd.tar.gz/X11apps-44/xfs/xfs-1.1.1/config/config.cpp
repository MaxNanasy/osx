# X font server configuration file
# See xfs(__appmansuffix__) man page for more information.

clone-self = on
use-syslog = off
catalogue = DEFAULTFONTPATH
error-file = FSERRORS
# in decipoints
default-point-size = 120
default-resolutions = 75,75,100,100
