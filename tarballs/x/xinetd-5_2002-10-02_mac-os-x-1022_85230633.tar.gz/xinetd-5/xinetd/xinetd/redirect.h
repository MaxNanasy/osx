#ifndef REDIRECT_H
#define REDIRECT_H

#include "server.h"

void redir_handler(struct server *serp);

#endif
