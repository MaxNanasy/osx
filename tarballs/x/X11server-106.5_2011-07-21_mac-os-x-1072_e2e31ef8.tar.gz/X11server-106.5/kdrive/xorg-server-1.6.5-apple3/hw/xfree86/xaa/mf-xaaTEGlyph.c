#define MSBFIRST
#define FIXEDBASE
#include "./xaaTEGlyph.c"
