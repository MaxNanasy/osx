#define MSBFIRST
#define TRIPLE_BITS
#define FIXEDBASE
#include "./xaaStipple.c"
