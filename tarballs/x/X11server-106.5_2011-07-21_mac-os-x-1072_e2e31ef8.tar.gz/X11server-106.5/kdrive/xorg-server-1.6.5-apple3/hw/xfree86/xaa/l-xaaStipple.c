#define LSBFIRST
#include "./xaaStipple.c"
