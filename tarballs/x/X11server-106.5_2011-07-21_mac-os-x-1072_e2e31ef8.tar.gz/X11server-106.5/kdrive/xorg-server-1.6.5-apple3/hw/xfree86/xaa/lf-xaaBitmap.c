#define LSBFIRST
#define FIXEDBASE
#include "./xaaBitmap.c"
