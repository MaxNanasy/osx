#define LSBFIRST
#define TRIPLE_BITS
#define FIXEDBASE
#include "./xaaBitmap.c"
