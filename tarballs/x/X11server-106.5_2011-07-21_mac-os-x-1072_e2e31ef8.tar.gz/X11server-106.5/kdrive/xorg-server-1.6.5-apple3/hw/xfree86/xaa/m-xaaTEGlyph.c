#define MSBFIRST
#include "./xaaTEGlyph.c"
