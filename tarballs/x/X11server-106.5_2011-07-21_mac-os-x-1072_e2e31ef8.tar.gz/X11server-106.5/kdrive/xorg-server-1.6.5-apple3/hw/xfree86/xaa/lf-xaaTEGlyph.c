#define LSBFIRST
#define FIXEDBASE
#include "./xaaTEGlyph.c"
