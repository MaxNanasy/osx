int this_is_just_here_to_make_automake_work() {
	return 0;
}
