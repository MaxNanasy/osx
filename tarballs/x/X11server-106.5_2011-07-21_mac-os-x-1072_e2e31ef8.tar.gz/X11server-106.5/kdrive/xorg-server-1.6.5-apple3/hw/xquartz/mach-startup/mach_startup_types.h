#ifndef _MACH_STARTUP_TYPES_H_
#define _MACH_STARTUP_TYPES_H_

#define STRING_T_SIZE 1024

typedef char string_t[STRING_T_SIZE];
typedef string_t * string_array_t;

#endif
