#ifndef XPYB_CONSTANT_H
#define XPYB_CONSTANT_H

#include <X11/X.h>
#include <X11/Xatom.h>

int xpybConstant_modinit(PyObject *m);

#endif
