#define MSBFIRST
#define FIXEDBASE
#include "./xaaBitmap.c"
