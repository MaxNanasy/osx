#define LSBFIRST
#define TRIPLE_BITS
#include "./xaaBitmap.c"
