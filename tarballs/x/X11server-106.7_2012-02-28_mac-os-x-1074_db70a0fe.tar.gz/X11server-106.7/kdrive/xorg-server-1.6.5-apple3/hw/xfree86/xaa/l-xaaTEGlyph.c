#define LSBFIRST
#include "./xaaTEGlyph.c"
