#define MSBFIRST
#define TRIPLE_BITS
#include "./xaaStipple.c"
