#define MSBFIRST
#include "./xaaStipple.c"
