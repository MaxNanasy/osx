#define LSBFIRST
#define FIXEDBASE
#include "./xaaStipple.c"
