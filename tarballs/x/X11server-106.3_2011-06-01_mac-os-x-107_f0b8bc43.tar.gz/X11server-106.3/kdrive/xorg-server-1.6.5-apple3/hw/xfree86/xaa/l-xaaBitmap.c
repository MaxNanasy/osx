#define LSBFIRST
#include "./xaaBitmap.c"
