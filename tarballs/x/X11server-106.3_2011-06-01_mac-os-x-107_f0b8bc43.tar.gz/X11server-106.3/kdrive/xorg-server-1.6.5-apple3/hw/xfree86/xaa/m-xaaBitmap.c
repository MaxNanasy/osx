#define MSBFIRST
#include "./xaaBitmap.c"
