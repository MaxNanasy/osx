#define MSBFIRST
#define TRIPLE_BITS
#include "./xaaBitmap.c"
