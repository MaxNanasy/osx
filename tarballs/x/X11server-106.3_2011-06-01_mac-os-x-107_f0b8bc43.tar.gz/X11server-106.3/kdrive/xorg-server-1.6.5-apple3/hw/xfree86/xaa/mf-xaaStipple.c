#define MSBFIRST
#define FIXEDBASE
#include "./xaaStipple.c"
