#include "cairoint.h"

CAIRO_HAS_HIDDEN_SYMBOLS
