
#ifndef HAVE_MYSQL
#define HAVE_MYSQL 0
#endif

#ifndef HAVE_BIND
#define HAVE_BIND 0
#endif

