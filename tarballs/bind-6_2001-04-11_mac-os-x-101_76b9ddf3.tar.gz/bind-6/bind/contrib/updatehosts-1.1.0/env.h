/* $Id: env.h,v 1.1.1.1 2001/01/31 03:59:15 zarzycki Exp $ */
struct environment {
	char *name;
	char *value;
};
