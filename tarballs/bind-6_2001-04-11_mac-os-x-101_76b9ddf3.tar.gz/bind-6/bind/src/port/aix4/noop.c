void
__bind_noop() {
	/* NOOP */
}
