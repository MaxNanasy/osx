/* Omitted from MPE. */

#define _PATH_DEVNULL "/dev/null"
