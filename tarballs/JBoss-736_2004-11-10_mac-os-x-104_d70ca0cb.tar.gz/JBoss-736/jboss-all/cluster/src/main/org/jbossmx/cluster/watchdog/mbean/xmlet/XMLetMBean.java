package org.jbossmx.cluster.watchdog.mbean.xmlet;

//import javax.management.ServiceNotFoundException;

import javax.management.loading.MLetMBean;

//import java.net.URL;

/**
 *
 */
public interface XMLetMBean extends MLetMBean
{
}