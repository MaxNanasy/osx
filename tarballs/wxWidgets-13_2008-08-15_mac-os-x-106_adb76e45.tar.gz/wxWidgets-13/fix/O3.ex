g/-O3\>/s//-Os/
w
