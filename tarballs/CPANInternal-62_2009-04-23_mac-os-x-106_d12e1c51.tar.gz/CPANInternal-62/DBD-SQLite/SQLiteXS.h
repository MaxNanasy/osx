
#ifndef _SQLITEXS_H
#define _SQLITEXS_H   1

/************************************************************************
    DBI Specific Stuff - Added by Matt Sergeant
 ************************************************************************/
#define NEED_DBIXS_VERSION 93
#include <DBIXS.h>
#include "dbdimp.h"
#include <dbd_xsh.h>

#include "sqlite3.h"
#include "ppport.h"

#endif
