package t::lib::B;
our @ISA = qw//;
1;
