package t::lib::F;
use c3;
use base ('t::lib::C', 't::lib::D');
1;