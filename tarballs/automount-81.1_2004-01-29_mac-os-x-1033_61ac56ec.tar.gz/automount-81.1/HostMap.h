#ifndef __HOST_MAP_H__
#define __HOST_MAP_H__

#import "AMMap.h"

@interface HostMap : Map
{
}

@end

#endif __HOST_MAP_H__
