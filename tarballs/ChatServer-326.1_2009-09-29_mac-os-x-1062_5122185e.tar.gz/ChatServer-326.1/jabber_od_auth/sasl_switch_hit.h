/*
 *  sasl_switch_hit.h
 *
 *  korver@apple.com
 *
 *  Copyright (c) 2009, Apple Inc. All rights reserved.
 */

#ifndef __SASL_SWITCH_HIT_H__
#define __SASL_SWITCH_HIT_H__

int sasl_switch_hit_register_apple_digest_md5(void);

#endif
