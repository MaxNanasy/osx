This directory contains bindings for the LLVM compiler infrastructure to allow
programs written in languages other than C or C++ to take advantage of the LLVM
infrastructure--for instance, a self-hosted compiler front-end.
