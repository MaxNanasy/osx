/* Define as the path of the `chmod' program. */
#undef CHMOD_PATH

/* Define if your sys/time.h defines struct timezone. */
#undef HAVE_STRUCT_TIMEZONE

/* Define if your gettimeofday takes only one argument. */
#undef GETTIMEOFDAY_ONE_ARGUMENT

/* Define if your gettimeofday takes a time zome argument. */
#undef HAVE_TIMEZONE
