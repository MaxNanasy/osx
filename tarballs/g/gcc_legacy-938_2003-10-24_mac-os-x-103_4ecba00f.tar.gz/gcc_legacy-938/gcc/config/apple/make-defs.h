#ifndef _MAKE_DEFS_

typedef char *make_string_t;

#endif _MAKE_DEFS_
