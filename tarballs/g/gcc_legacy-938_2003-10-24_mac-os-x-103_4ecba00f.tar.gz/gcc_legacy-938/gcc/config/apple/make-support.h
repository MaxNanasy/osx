extern void v_make_support (int type, const char *name, const char *file,
			    int line, const char *msg, va_list ap);
extern void   make_support (int type, const char *name, const char *file,
			    int line, const char *msg, ...);
