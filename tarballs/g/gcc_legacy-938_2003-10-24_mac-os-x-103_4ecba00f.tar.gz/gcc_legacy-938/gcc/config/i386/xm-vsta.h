/* Use semicolons to separate elements of a path.  */
#define PATH_SEPARATOR ';'
