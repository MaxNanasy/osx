// -*- C++ -*- backward compatiblity header.
// Copyright (C) 1994 Free Software Foundation

#ifndef __COMPLEX_H__
#include <complex>
#endif
