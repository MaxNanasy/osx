/* Define to use grep's error-checking malloc in the kwset routines.  */
#undef GREP

/* Package name. */
#undef PACKAGE

/* Version number. */
#undef VERSION

/* Define to `int' if <sys/types.h> doesn't define.  */
#undef ssize_t

/* Hack for Visual C++ suggested by irox. */
#undef alloca

/*
 * Internationalization stuffs.
 */

#undef HAVE_STPCPY

#undef ENABLE_NLS

#undef HAVE_CATGETS

#undef HAVE_GETTEXT

#undef HAVE_LC_MESSAGES

/*
 * DOS specific
 */
#undef HAVE_DOS_FILE_NAMES
