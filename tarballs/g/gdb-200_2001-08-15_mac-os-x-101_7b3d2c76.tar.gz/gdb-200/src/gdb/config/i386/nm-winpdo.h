/* Macro definitions for i386 running under the win32 API Unix. */
