extern bfd *
check_read (const char *name, CORE_ADDR address, CORE_ADDR length);

extern void
next_update_cfm (void);
