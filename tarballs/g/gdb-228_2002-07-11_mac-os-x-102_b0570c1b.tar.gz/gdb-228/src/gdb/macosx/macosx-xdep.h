#ifndef __GDB_MACOSX_XDEP_H__
#define __GDB_MACOSX_XDEP_H__


#endif /* __GDB_MACOSX_XDEP_H__ */
