/* OBSOLETE #include <stdio.h> */
/* OBSOLETE #include <pthread.h> */
/* OBSOLETE #include <sys/types.h> */
/* OBSOLETE  */
/* OBSOLETE int main(void){ */
/* OBSOLETE pid_t pid; */
/* OBSOLETE  */
/* OBSOLETE switch (pid = fork()){ */
/* OBSOLETE   case 0: */
/* OBSOLETE     printf("child\n"); */
/* OBSOLETE     break; */
/* OBSOLETE   default: */
/* OBSOLETE     printf("parent\n"); */
/* OBSOLETE     break; */
/* OBSOLETE   } */
/* OBSOLETE   return 0; */
/* OBSOLETE } */
