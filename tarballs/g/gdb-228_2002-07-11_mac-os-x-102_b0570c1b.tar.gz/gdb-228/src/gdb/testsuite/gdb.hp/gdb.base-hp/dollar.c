#ifdef PROTOTYPES
int main (int argc, char **argv)
#else
main (argc, argv, envp)
     int argc;
     char **argv;
#endif
{
    return 0;
}
