int global_from_secondary = 9012;
int function_from_secondary()
{
    static int local_static = 3456;
    return 0;
}

garbage()
{
	return 0;
}
