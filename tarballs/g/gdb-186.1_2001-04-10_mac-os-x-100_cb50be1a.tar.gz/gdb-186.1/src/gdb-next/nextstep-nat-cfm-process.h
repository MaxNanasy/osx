extern void next_update_cfm PARAMS ((void));
