#include "symtab.h"

bfd *mach_o_inferior_bfd
PARAMS ((CORE_ADDR addr, CORE_ADDR offset));
