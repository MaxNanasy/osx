/* Configuration for GCC for Intel i386 running OSF/1 1.3.  */

#ifndef HZ
#include <machine/machtime.h>
#define HZ DEFAULT_CLK_TCK
#endif
