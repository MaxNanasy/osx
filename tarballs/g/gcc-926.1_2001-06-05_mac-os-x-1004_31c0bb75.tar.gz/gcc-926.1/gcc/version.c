char *version_string = "2.95.2 19991024 (release)";
