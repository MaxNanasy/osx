#include "../cp/decl2.c"
