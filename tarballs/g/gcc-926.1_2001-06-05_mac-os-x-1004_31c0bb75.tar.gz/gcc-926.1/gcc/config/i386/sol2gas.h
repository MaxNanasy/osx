/* Definitions of target machine for GNU compiler, for SPARC running
   Solaris 2 with GNU as up to 2.9.5.0.12.
   
   Copyright (C) 1999 Free Software Foundation, Inc.
*/

#ifndef GAS_DOES_NOT_SUPPORT_MINUS_S
#define GAS_DOES_NOT_SUPPORT_MINUS_S 1
#endif

#include "i386/sol2.h"
