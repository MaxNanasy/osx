extern void layout_addresses(
    void);
