#ifndef __GDB_MACOSX_NAT_CFM_IO_H__
#define __GDB_MACOSX_NAT_CFM_IO_H__

#include "symtab.h"

#endif /* __GDB_MACOSX_NAT_CFM_IO_H__ */
