/* An include file that actually causes code to be generated in the
   including file.  This is known to cause problems on some systems. */

static void
foo (x)
int x;
{
    bar (x++);
    bar (x++);
    bar (x++);
    bar (x++);
    bar (x++);
    bar (x++);
    bar (x++);
    bar (x++);
    bar (x++);
    bar (x++);
    bar (x++);
    bar (x++);
    bar (x++);
    bar (x++);
    bar (x++);
    bar (x++);
    bar (x++);
    bar (x++);
    bar (x++);
    bar (x++);
    bar (x++);
    bar (x++);
    bar (x++);
    bar (x++);
    bar (x++);
    bar (x++);
    bar (x++);
    bar (x++);
}
