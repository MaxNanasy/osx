#include "x3.h"
#include <stdio.h>

int acomm;

void PP::print()
{
  printf("In PP::print()\n");
}

void QQ::print()
{
  printf("In QQ::print()\n");
}
