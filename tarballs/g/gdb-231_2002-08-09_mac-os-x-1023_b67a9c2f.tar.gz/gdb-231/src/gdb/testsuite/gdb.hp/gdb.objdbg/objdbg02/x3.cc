#include <stdio.h>

void foo3()
{
  printf("In foo3.\n");
}
