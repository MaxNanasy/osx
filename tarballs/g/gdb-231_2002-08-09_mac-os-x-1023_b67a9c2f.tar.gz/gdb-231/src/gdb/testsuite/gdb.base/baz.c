static int bazx __attribute__ ((section (".data02"))) = 'b' + 'a' + 'z';

int baz (int x)
{
  if (x)
    return bazx;
  else
    return 0;
}
