struct s {
  int a;
  int b;
};
