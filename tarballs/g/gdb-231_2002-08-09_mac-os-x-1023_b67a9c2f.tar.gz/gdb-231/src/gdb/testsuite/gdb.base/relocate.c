static int static_foo = 1;
static int static_bar = 2;

int global_foo = 3;
int global_bar = 4;

int
function_foo ()
{
  return 5;
}

int
function_bar ()
{
  return 6;
}
