/* Functions defined in this file */
void extern_func1_1 (int, char *, unsigned long);
void extern_func1_2 (int, char *, unsigned long);
void extern_func1_3 (int, char *, unsigned long);
void extern_func1_4 (int, char *, unsigned long);
void extern_func1_5 (int, char *, unsigned long);
void extern_func1_6 (int, char *, unsigned long);
void extern_func1_7 (int, char *, unsigned long);
void extern_func1_8 (int, char *, unsigned long);
void extern_func1_9 (int, char *, unsigned long);
void extern_func1_10 (int, char *, unsigned long);
void extern_func1_11 (int, char *, unsigned long);
void extern_func1_12 (int, char *, unsigned long);
void extern_func1_13 (int, char *, unsigned long);
void extern_func1_14 (int, char *, unsigned long);
void extern_func1_15 (int, char *, unsigned long);

void
extern_func1_1 (int a, char *b, unsigned long c)
{
  extern_func1_2 (a, b, c);
}

void
extern_func1_2 (int a, char *b, unsigned long c)
{
  extern_func1_3 (a, b, c);
}

void
extern_func1_3 (int a, char *b, unsigned long c)
{
  extern_func1_4 (a, b, c);
}

void
extern_func1_4 (int a, char *b, unsigned long c)
{
  extern_func1_5 (a, b, c);
}

void
extern_func1_5 (int a, char *b, unsigned long c)
{
  extern_func1_6 (a, b, c);
}

void
extern_func1_6 (int a, char *b, unsigned long c)
{
  extern_func1_7 (a, b, c);
}

void
extern_func1_7 (int a, char *b, unsigned long c)
{
  extern_func1_8 (a, b, c);
}

void
extern_func1_8 (int a, char *b, unsigned long c)
{
  extern_func1_9 (a, b, c);
}

void
extern_func1_9 (int a, char *b, unsigned long c)
{
  extern_func1_10 (a, b, c);
}

void
extern_func1_10 (int a, char *b, unsigned long c)
{
  extern_func1_11 (a, b, c);
}

void
extern_func1_11 (int a, char *b, unsigned long c)
{
  extern_func1_12 (a, b, c);
}

void
extern_func1_12 (int a, char *b, unsigned long c)
{
  extern_func1_13 (a, b, c);
}

void
extern_func1_13 (int a, char *b, unsigned long c)
{
  extern_func1_14 (a, b, c);
}

void
extern_func1_14 (int a, char *b, unsigned long c)
{
  extern_func1_15 (a, b, c);
}

void
extern_func1_15 (int a, char *b, unsigned long c)
{
  /* THE END */
  return;
}
