#define inttostr imaxtostr
#define inttype intmax_t
#include "inttostr.c"
