#define	tINT	258
#define	tDOUBLE	259
#define	tSTRING	260
#define	tCLASS	261
#define	tBEGIN	262
#define	tEND	263
#define	ASSIGN	264
#define	PRINTER	265
#define	NAME	266
#define	DRIVER	267
#define	COLOR	268
#define	NOCOLOR	269
#define	MODEL	270
#define	LANGUAGE	271
#define	BRIGHTNESS	272
#define	GAMMA	273
#define	CONTRAST	274
#define	CYAN	275
#define	MAGENTA	276
#define	YELLOW	277
#define	SATURATION	278
#define	DENSITY	279
#define	ENDPRINTER	280
#define	VALUE	281


extern YYSTYPE yylval;
