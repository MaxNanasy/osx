#ifndef PyObjC_SUPER_H
#define PyObjC_SUPER_H

extern PyTypeObject PyObjCSuper_Type;

#endif /* PyObjC_SUPER_H */
