#import "NSPreferences.h"

@interface JVPreferencesController : NSPreferences {}
@end
