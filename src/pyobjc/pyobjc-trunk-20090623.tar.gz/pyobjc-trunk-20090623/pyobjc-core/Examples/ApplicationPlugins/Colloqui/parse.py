from PyObjCTools.WrapperGenerator import *
import sys

generateWrappersForFramework(sys.stdout,
    'Colloquy Plugin SDK')
